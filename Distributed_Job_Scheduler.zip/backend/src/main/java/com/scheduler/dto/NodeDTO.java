package com.scheduler.dto;

import com.scheduler.entity.SchedulerNode;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class NodeDTO {
    private Long id;
    private String nodeId;
    private String hostname;
    private String ipAddress;
    private Integer port;
    private String status;
    private boolean isLeader;
    private LocalDateTime registeredAt;
    private LocalDateTime lastHeartbeatAt;
    private int activeJobs;

    public static NodeDTO from(SchedulerNode node, int activeJobs) {
        NodeDTO dto = new NodeDTO();
        dto.setId(node.getId());
        dto.setNodeId(node.getNodeId());
        dto.setHostname(node.getHostname());
        dto.setIpAddress(node.getIpAddress());
        dto.setPort(node.getPort());
        dto.setStatus(node.getStatus().name());
        dto.setLeader(node.isLeader());
        dto.setRegisteredAt(node.getRegisteredAt());
        dto.setLastHeartbeatAt(node.getLastHeartbeatAt());
        dto.setActiveJobs(activeJobs);
        return dto;
    }
}
