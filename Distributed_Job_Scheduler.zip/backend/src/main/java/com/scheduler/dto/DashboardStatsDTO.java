package com.scheduler.dto;

import lombok.Data;

import java.util.List;

@Data
public class DashboardStatsDTO {
    private long totalJobs;
    private long activeJobs;
    private long pausedJobs;
    private long totalNodes;
    private long activeNodes;
    private String leaderNode;
    private long totalExecutions;
    private long successfulExecutions;
    private long failedExecutions;
    private List<JobExecutionDTO> recentExecutions;
    private List<StatusCountDTO> jobsByStatus;
    private List<DayCountDTO> executionsByDay;

    @Data
    public static class StatusCountDTO {
        private String status;
        private long count;

        public StatusCountDTO(String status, long count) {
            this.status = status;
            this.count = count;
        }
    }

    @Data
    public static class DayCountDTO {
        private String day;
        private long count;

        public DayCountDTO(String day, long count) {
            this.day = day;
            this.count = count;
        }
    }
}
