package com.scheduler.dto;

import com.scheduler.entity.JobExecution;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class JobExecutionDTO {
    private Long id;
    private Long jobId;
    private String jobName;
    private Long nodeId;
    private String nodeName;
    private String status;
    private LocalDateTime startedAt;
    private LocalDateTime completedAt;
    private Long durationMs;
    private String output;
    private String errorMessage;

    public static JobExecutionDTO from(JobExecution exec) {
        return from(exec, null, null);
    }

    public static JobExecutionDTO from(JobExecution exec, String jobName, String nodeName) {
        JobExecutionDTO dto = new JobExecutionDTO();
        dto.setId(exec.getId());
        dto.setJobId(exec.getJobId());
        dto.setJobName(jobName);
        dto.setNodeId(exec.getNodeId());
        dto.setNodeName(nodeName);
        dto.setStatus(exec.getStatus().name());
        dto.setStartedAt(exec.getStartedAt());
        dto.setCompletedAt(exec.getCompletedAt());
        dto.setDurationMs(exec.getDurationMs());
        dto.setOutput(exec.getOutput());
        dto.setErrorMessage(exec.getErrorMessage());
        return dto;
    }
}
