package com.scheduler.dto;

import com.scheduler.entity.Job;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class JobDTO {
    private Long id;
    private String name;
    private String description;
    private String cronExpression;
    private String status;
    private String jobType;
    private String payload;
    private Long assignedNodeId;
    private LocalDateTime lastExecutedAt;
    private LocalDateTime nextExecutionAt;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private int totalExecutions;
    private int successfulExecutions;
    private int failedExecutions;

    public static JobDTO from(Job job) {
        JobDTO dto = new JobDTO();
        dto.setId(job.getId());
        dto.setName(job.getName());
        dto.setDescription(job.getDescription());
        dto.setCronExpression(job.getCronExpression());
        dto.setStatus(job.getStatus().name());
        dto.setJobType(job.getJobType().name());
        dto.setPayload(job.getPayload());
        dto.setAssignedNodeId(job.getAssignedNodeId());
        dto.setLastExecutedAt(job.getLastExecutedAt());
        dto.setNextExecutionAt(job.getNextExecutionAt());
        dto.setCreatedAt(job.getCreatedAt());
        dto.setUpdatedAt(job.getUpdatedAt());
        dto.setTotalExecutions(job.getTotalExecutions());
        dto.setSuccessfulExecutions(job.getSuccessfulExecutions());
        dto.setFailedExecutions(job.getFailedExecutions());
        return dto;
    }
}
