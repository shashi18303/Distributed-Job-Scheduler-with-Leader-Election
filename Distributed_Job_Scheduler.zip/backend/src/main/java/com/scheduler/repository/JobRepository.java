package com.scheduler.repository;

import com.scheduler.entity.Job;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JobRepository extends JpaRepository<Job, Long> {
    Page<Job> findByStatus(Job.JobStatus status, Pageable pageable);
    List<Job> findByStatus(Job.JobStatus status);

    @Query("SELECT COUNT(j) FROM Job j WHERE j.status = 'ACTIVE'")
    long countActiveJobs();

    @Query("SELECT COUNT(j) FROM Job j WHERE j.status = 'PAUSED'")
    long countPausedJobs();

    @Query("SELECT j.status as status, COUNT(j) as count FROM Job j GROUP BY j.status")
    List<Object[]> countByStatus();
}
