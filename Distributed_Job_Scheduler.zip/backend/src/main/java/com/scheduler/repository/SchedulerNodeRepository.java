package com.scheduler.repository;

import com.scheduler.entity.SchedulerNode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface SchedulerNodeRepository extends JpaRepository<SchedulerNode, Long> {
    Optional<SchedulerNode> findByNodeId(String nodeId);
    Optional<SchedulerNode> findByLeaderTrue();
    List<SchedulerNode> findByStatus(SchedulerNode.NodeStatus status);

    @Modifying
    @Query("UPDATE SchedulerNode n SET n.status = 'FAILED', n.leader = false WHERE n.lastHeartbeatAt < :timeout AND n.status = 'ACTIVE'")
    int markTimedOutNodes(LocalDateTime timeout);

    @Query("SELECT COUNT(n) FROM SchedulerNode n WHERE n.status = 'ACTIVE'")
    long countActiveNodes();
}
