package com.scheduler.repository;

import com.scheduler.entity.JobExecution;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface JobExecutionRepository extends JpaRepository<JobExecution, Long> {
    Page<JobExecution> findByJobId(Long jobId, Pageable pageable);
    Page<JobExecution> findByStatus(JobExecution.ExecutionStatus status, Pageable pageable);
    Page<JobExecution> findByJobIdAndStatus(Long jobId, JobExecution.ExecutionStatus status, Pageable pageable);

    List<JobExecution> findTop10ByOrderByStartedAtDesc();

    @Query("SELECT COUNT(e) FROM JobExecution e WHERE e.status = 'SUCCESS'")
    long countSuccessful();

    @Query("SELECT COUNT(e) FROM JobExecution e WHERE e.status = 'FAILED'")
    long countFailed();

    @Query("SELECT CAST(e.startedAt AS date) as day, COUNT(e) as count FROM JobExecution e WHERE e.startedAt >= :since GROUP BY CAST(e.startedAt AS date) ORDER BY CAST(e.startedAt AS date)")
    List<Object[]> countByDay(LocalDateTime since);
}
