package com.scheduler.repository;

import com.scheduler.entity.LeaderElection;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface LeaderElectionRepository extends JpaRepository<LeaderElection, Long> {
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT l FROM LeaderElection l WHERE l.lockName = :lockName")
    Optional<LeaderElection> findByLockNameForUpdate(String lockName);

    Optional<LeaderElection> findByLockName(String lockName);
}
