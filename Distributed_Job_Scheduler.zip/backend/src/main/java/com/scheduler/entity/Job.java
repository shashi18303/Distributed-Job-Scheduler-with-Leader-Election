package com.scheduler.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "jobs")
@Data
@NoArgsConstructor
public class Job {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(name = "cron_expression", nullable = false)
    private String cronExpression;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private JobStatus status = JobStatus.ACTIVE;

    @Enumerated(EnumType.STRING)
    @Column(name = "job_type", nullable = false)
    private JobType jobType = JobType.CUSTOM;

    @Column(columnDefinition = "TEXT")
    private String payload;

    @Column(name = "assigned_node_id")
    private Long assignedNodeId;

    @Column(name = "last_executed_at")
    private LocalDateTime lastExecutedAt;

    @Column(name = "next_execution_at")
    private LocalDateTime nextExecutionAt;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "total_executions")
    private int totalExecutions = 0;

    @Column(name = "successful_executions")
    private int successfulExecutions = 0;

    @Column(name = "failed_executions")
    private int failedExecutions = 0;

    public enum JobStatus {
        ACTIVE, PAUSED, DISABLED
    }

    public enum JobType {
        HTTP_REQUEST, SHELL_COMMAND, DATA_CLEANUP, EMAIL_NOTIFICATION, REPORT_GENERATION, CUSTOM
    }
}
