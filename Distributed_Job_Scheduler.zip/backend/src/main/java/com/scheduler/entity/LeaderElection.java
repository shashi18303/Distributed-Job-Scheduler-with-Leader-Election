package com.scheduler.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "leader_election")
@Data
@NoArgsConstructor
public class LeaderElection {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "lock_name", nullable = false, unique = true)
    private String lockName = "LEADER_LOCK";

    @Column(name = "node_id")
    private String nodeId;

    @Column(name = "acquired_at")
    private LocalDateTime acquiredAt;

    @Column(name = "expires_at")
    private LocalDateTime expiresAt;
}
