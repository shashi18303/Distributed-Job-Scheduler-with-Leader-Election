package com.scheduler.config;

import com.scheduler.entity.Job;
import com.scheduler.entity.JobExecution;
import com.scheduler.repository.JobExecutionRepository;
import com.scheduler.repository.JobRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataSeeder implements CommandLineRunner {

    private final JobRepository jobRepository;
    private final JobExecutionRepository executionRepository;

    @Override
    public void run(String... args) {
        if (jobRepository.count() > 0) return;

        log.info("Seeding initial data...");

        Job j1 = new Job();
        j1.setName("Daily Database Cleanup");
        j1.setDescription("Removes expired sessions and old audit logs from the database");
        j1.setCronExpression("0 0 2 * * *");
        j1.setJobType(Job.JobType.DATA_CLEANUP);
        j1.setStatus(Job.JobStatus.ACTIVE);
        j1.setTotalExecutions(42);
        j1.setSuccessfulExecutions(40);
        j1.setFailedExecutions(2);
        j1.setLastExecutedAt(LocalDateTime.now().minusHours(6));
        jobRepository.save(j1);

        Job j2 = new Job();
        j2.setName("Hourly Health Check");
        j2.setDescription("Pings all downstream services and reports status");
        j2.setCronExpression("0 0 * * * *");
        j2.setJobType(Job.JobType.HTTP_REQUEST);
        j2.setPayload("{\"url\": \"https://api.example.com/health\", \"timeout\": 5000}");
        j2.setStatus(Job.JobStatus.ACTIVE);
        j2.setTotalExecutions(168);
        j2.setSuccessfulExecutions(165);
        j2.setFailedExecutions(3);
        j2.setLastExecutedAt(LocalDateTime.now().minusMinutes(45));
        jobRepository.save(j2);

        Job j3 = new Job();
        j3.setName("Weekly Report Generation");
        j3.setDescription("Generates weekly analytics report and sends to stakeholders");
        j3.setCronExpression("0 0 9 * * MON");
        j3.setJobType(Job.JobType.REPORT_GENERATION);
        j3.setStatus(Job.JobStatus.ACTIVE);
        j3.setTotalExecutions(12);
        j3.setSuccessfulExecutions(12);
        j3.setFailedExecutions(0);
        j3.setLastExecutedAt(LocalDateTime.now().minusDays(3));
        jobRepository.save(j3);

        Job j4 = new Job();
        j4.setName("Email Digest");
        j4.setDescription("Sends daily email digest to subscribed users");
        j4.setCronExpression("0 30 8 * * *");
        j4.setJobType(Job.JobType.EMAIL_NOTIFICATION);
        j4.setStatus(Job.JobStatus.PAUSED);
        j4.setTotalExecutions(30);
        j4.setSuccessfulExecutions(28);
        j4.setFailedExecutions(2);
        j4.setLastExecutedAt(LocalDateTime.now().minusDays(1));
        jobRepository.save(j4);

        Job j5 = new Job();
        j5.setName("Log Rotation Script");
        j5.setDescription("Compresses and archives logs older than 7 days");
        j5.setCronExpression("0 0 3 * * SUN");
        j5.setJobType(Job.JobType.SHELL_COMMAND);
        j5.setPayload("find /var/log -name '*.log' -mtime +7 -exec gzip {} \\;");
        j5.setStatus(Job.JobStatus.ACTIVE);
        j5.setTotalExecutions(8);
        j5.setSuccessfulExecutions(8);
        j5.setFailedExecutions(0);
        j5.setLastExecutedAt(LocalDateTime.now().minusDays(6));
        jobRepository.save(j5);

        // Seed some recent executions
        List<Job> jobs = jobRepository.findAll();
        for (Job job : jobs) {
            for (int i = 0; i < 5; i++) {
                JobExecution exec = new JobExecution();
                exec.setJobId(job.getId());
                exec.setStartedAt(LocalDateTime.now().minusHours(i * 3 + 1));
                exec.setCompletedAt(LocalDateTime.now().minusHours(i * 3 + 1).plusSeconds(2));
                exec.setDurationMs((long)(500 + Math.random() * 2000));
                boolean success = Math.random() > 0.15;
                exec.setStatus(success ? JobExecution.ExecutionStatus.SUCCESS : JobExecution.ExecutionStatus.FAILED);
                exec.setOutput(success ? "Completed successfully" : null);
                exec.setErrorMessage(success ? null : "Connection timeout");
                executionRepository.save(exec);
            }
        }

        log.info("Seeding complete: {} jobs, {} executions", jobRepository.count(), executionRepository.count());
    }
}
