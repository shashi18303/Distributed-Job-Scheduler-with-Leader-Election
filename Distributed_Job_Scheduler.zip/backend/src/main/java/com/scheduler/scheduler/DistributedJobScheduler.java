package com.scheduler.scheduler;

import com.scheduler.entity.Job;
import com.scheduler.repository.JobRepository;
import com.scheduler.service.ExecutionService;
import com.scheduler.service.LeaderElectionService;
import com.scheduler.service.NodeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.support.CronExpression;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

@Component
@RequiredArgsConstructor
@Slf4j
public class DistributedJobScheduler {

    private final NodeService nodeService;
    private final LeaderElectionService leaderElectionService;
    private final JobRepository jobRepository;
    private final ExecutionService executionService;

    @Value("${scheduler.node.heartbeat-interval-ms:5000}")
    private long heartbeatIntervalMs;

    @Value("${scheduler.node.node-timeout-ms:15000}")
    private long nodeTimeoutMs;

    private final ScheduledExecutorService scheduledExecutor =
        Executors.newScheduledThreadPool(4);

    private final ExecutorService jobExecutor =
        Executors.newFixedThreadPool(10);

    private final AtomicBoolean initialized = new AtomicBoolean(false);

    @PostConstruct
    public void initialize() {
        log.info("Initializing Distributed Job Scheduler node...");
        try {
            nodeService.registerCurrentNode();
            initialized.set(true);
            log.info("Node registered successfully. Starting scheduler tasks.");
        } catch (Exception e) {
            log.error("Failed to initialize scheduler node", e);
        }
    }

    @Scheduled(fixedDelayString = "${scheduler.node.heartbeat-interval-ms:5000}")
    public void heartbeat() {
        if (!initialized.get()) return;
        try {
            nodeService.sendHeartbeat();
            nodeService.detectAndMarkFailedNodes(nodeTimeoutMs);
            leaderElectionService.tryAcquireLeadership();
        } catch (Exception e) {
            log.error("Error during heartbeat", e);
        }
    }

    @Scheduled(fixedDelay = 10000)
    public void checkAndRunDueJobs() {
        if (!initialized.get() || !leaderElectionService.isCurrentlyLeader()) return;

        try {
            List<Job> activeJobs = jobRepository.findByStatus(Job.JobStatus.ACTIVE);
            LocalDateTime now = LocalDateTime.now();

            for (Job job : activeJobs) {
                if (isDue(job, now)) {
                    log.info("Triggering job: {} [{}]", job.getName(), job.getCronExpression());
                    final Job jobToRun = job;
                    final Long nodeDbId = nodeService.getCurrentNodeDbId();
                    jobExecutor.submit(() -> {
                        try {
                            executionService.executeJob(jobToRun, nodeDbId);
                        } catch (Exception e) {
                            log.error("Failed to execute job {}", jobToRun.getId(), e);
                        }
                    });
                    // Update next execution time
                    job.setLastExecutedAt(now);
                    jobRepository.save(job);
                }
            }
        } catch (Exception e) {
            log.error("Error checking due jobs", e);
        }
    }

    private boolean isDue(Job job, LocalDateTime now) {
        try {
            CronExpression expr = CronExpression.parse(normalizeCron(job.getCronExpression()));
            LocalDateTime lastRun = job.getLastExecutedAt();
            if (lastRun == null) {
                // Never ran — check if it should have run in the past minute
                LocalDateTime oneMinuteAgo = now.minusMinutes(1);
                LocalDateTime next = expr.next(oneMinuteAgo);
                return next != null && !next.isAfter(now);
            }
            LocalDateTime next = expr.next(lastRun);
            return next != null && !next.isAfter(now);
        } catch (Exception e) {
            log.warn("Invalid cron expression for job {}: {}", job.getId(), job.getCronExpression());
            return false;
        }
    }

    private String normalizeCron(String cron) {
        // Spring CronExpression requires 6 fields (with seconds)
        String[] parts = cron.trim().split("\\s+");
        if (parts.length == 5) {
            return "0 " + cron; // prepend seconds
        }
        return cron;
    }

    @PreDestroy
    public void shutdown() {
        log.info("Shutting down scheduler node...");
        leaderElectionService.releaseLeadership();
        scheduledExecutor.shutdownNow();
        jobExecutor.shutdownNow();
    }
}
