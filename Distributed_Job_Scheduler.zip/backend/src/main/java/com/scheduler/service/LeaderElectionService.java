package com.scheduler.service;

import com.scheduler.entity.LeaderElection;
import com.scheduler.repository.LeaderElectionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class LeaderElectionService {

    private static final String LEADER_LOCK = "LEADER_LOCK";

    private final LeaderElectionRepository leaderElectionRepository;
    private final NodeService nodeService;

    @Value("${scheduler.node.leader-lease-ms:10000}")
    private long leaderLeaseMs;

    private volatile boolean currentlyLeader = false;

    @Transactional
    public boolean tryAcquireLeadership() {
        String nodeId = nodeService.getCurrentNodeId();
        if (nodeId == null) return false;

        try {
            Optional<LeaderElection> lockOpt = leaderElectionRepository.findByLockNameForUpdate(LEADER_LOCK);

            if (lockOpt.isEmpty()) {
                LeaderElection lock = new LeaderElection();
                lock.setLockName(LEADER_LOCK);
                lock.setNodeId(nodeId);
                lock.setAcquiredAt(LocalDateTime.now());
                lock.setExpiresAt(LocalDateTime.now().plusNanos(leaderLeaseMs * 1_000_000L));
                leaderElectionRepository.save(lock);
                becomeLeader(nodeId);
                return true;
            }

            LeaderElection lock = lockOpt.get();

            if (lock.getNodeId() != null && lock.getNodeId().equals(nodeId)) {
                lock.setExpiresAt(LocalDateTime.now().plusNanos(leaderLeaseMs * 1_000_000L));
                leaderElectionRepository.save(lock);
                if (!currentlyLeader) becomeLeader(nodeId);
                return true;
            }

            if (lock.getExpiresAt() == null || LocalDateTime.now().isAfter(lock.getExpiresAt())) {
                log.info("Leader lease expired for node {}, acquiring leadership", lock.getNodeId());
                lock.setNodeId(nodeId);
                lock.setAcquiredAt(LocalDateTime.now());
                lock.setExpiresAt(LocalDateTime.now().plusNanos(leaderLeaseMs * 1_000_000L));
                leaderElectionRepository.save(lock);
                becomeLeader(nodeId);
                return true;
            }

            if (currentlyLeader) {
                log.warn("Lost leadership to another node");
                currentlyLeader = false;
            }
            return false;
        } catch (Exception e) {
            log.error("Error during leader election", e);
            return false;
        }
    }

    private void becomeLeader(String nodeId) {
        if (!currentlyLeader) {
            log.info("Node {} became the leader", nodeId);
            currentlyLeader = true;
        }
        nodeService.markNodeAsLeader(nodeId);
    }

    public boolean isCurrentlyLeader() {
        return currentlyLeader;
    }

    @Transactional
    public void releaseLeadership() {
        String nodeId = nodeService.getCurrentNodeId();
        if (nodeId == null) return;
        leaderElectionRepository.findByLockName(LEADER_LOCK).ifPresent(lock -> {
            if (nodeId.equals(lock.getNodeId())) {
                lock.setNodeId(null);
                lock.setExpiresAt(LocalDateTime.now().minusSeconds(1));
                leaderElectionRepository.save(lock);
                log.info("Node {} released leadership", nodeId);
            }
        });
        currentlyLeader = false;
        nodeService.resignLeadership();
    }
}
