package com.scheduler.service;

import com.scheduler.dto.DashboardStatsDTO;
import com.scheduler.dto.JobDTO;
import com.scheduler.dto.PageResponse;
import com.scheduler.entity.Job;
import com.scheduler.repository.JobRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class JobService {

    private final JobRepository jobRepository;

    public PageResponse<JobDTO> listJobs(String status, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        Page<Job> jobPage;
        if (status != null && !status.isBlank()) {
            try {
                Job.JobStatus jobStatus = Job.JobStatus.valueOf(status.toUpperCase());
                jobPage = jobRepository.findByStatus(jobStatus, pageable);
            } catch (IllegalArgumentException e) {
                jobPage = jobRepository.findAll(pageable);
            }
        } else {
            jobPage = jobRepository.findAll(pageable);
        }
        return PageResponse.from(jobPage.map(JobDTO::from));
    }

    @Transactional
    public JobDTO createJob(Map<String, Object> body) {
        Job job = new Job();
        job.setName((String) body.get("name"));
        job.setDescription((String) body.get("description"));
        job.setCronExpression((String) body.get("cronExpression"));
        job.setPayload((String) body.get("payload"));
        job.setStatus(Job.JobStatus.ACTIVE);
        String jobType = (String) body.getOrDefault("jobType", "CUSTOM");
        try {
            job.setJobType(Job.JobType.valueOf(jobType.toUpperCase()));
        } catch (IllegalArgumentException e) {
            job.setJobType(Job.JobType.CUSTOM);
        }
        return JobDTO.from(jobRepository.save(job));
    }

    public JobDTO getJob(Long id) {
        return jobRepository.findById(id)
            .map(JobDTO::from)
            .orElseThrow(() -> new RuntimeException("Job not found: " + id));
    }

    @Transactional
    public JobDTO updateJob(Long id, Map<String, Object> body) {
        Job job = jobRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Job not found: " + id));
        if (body.containsKey("name")) job.setName((String) body.get("name"));
        if (body.containsKey("description")) job.setDescription((String) body.get("description"));
        if (body.containsKey("cronExpression")) job.setCronExpression((String) body.get("cronExpression"));
        if (body.containsKey("payload")) job.setPayload((String) body.get("payload"));
        if (body.containsKey("jobType")) {
            try {
                job.setJobType(Job.JobType.valueOf(((String) body.get("jobType")).toUpperCase()));
            } catch (IllegalArgumentException ignored) {}
        }
        job.setUpdatedAt(LocalDateTime.now());
        return JobDTO.from(jobRepository.save(job));
    }

    @Transactional
    public void deleteJob(Long id) {
        if (!jobRepository.existsById(id)) throw new RuntimeException("Job not found: " + id);
        jobRepository.deleteById(id);
    }

    @Transactional
    public JobDTO pauseJob(Long id) {
        Job job = jobRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Job not found: " + id));
        job.setStatus(Job.JobStatus.PAUSED);
        job.setUpdatedAt(LocalDateTime.now());
        return JobDTO.from(jobRepository.save(job));
    }

    @Transactional
    public JobDTO resumeJob(Long id) {
        Job job = jobRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Job not found: " + id));
        job.setStatus(Job.JobStatus.ACTIVE);
        job.setUpdatedAt(LocalDateTime.now());
        return JobDTO.from(jobRepository.save(job));
    }

    public long countActive() { return jobRepository.countActiveJobs(); }
    public long countPaused() { return jobRepository.countPausedJobs(); }
    public long countTotal() { return jobRepository.count(); }

    public List<DashboardStatsDTO.StatusCountDTO> getJobStatusCounts() {
        return jobRepository.countByStatus().stream()
            .map(row -> new DashboardStatsDTO.StatusCountDTO(row[0].toString(), ((Number) row[1]).longValue()))
            .collect(java.util.stream.Collectors.toList());
    }
}
