package com.scheduler.service;

import com.scheduler.dto.DashboardStatsDTO;
import com.scheduler.repository.JobRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StatsService {

    private final JobService jobService;
    private final ExecutionService executionService;
    private final NodeService nodeService;

    public DashboardStatsDTO getDashboardStats() {
        DashboardStatsDTO stats = new DashboardStatsDTO();

        stats.setTotalJobs(jobService.countTotal());
        stats.setActiveJobs(jobService.countActive());
        stats.setPausedJobs(jobService.countPaused());
        stats.setTotalNodes(nodeService.countTotalNodes());
        stats.setActiveNodes(nodeService.countActiveNodes());

        nodeService.getLeaderNode().ifPresentOrElse(
            leader -> stats.setLeaderNode(leader.getHostname()),
            () -> stats.setLeaderNode(null)
        );

        stats.setTotalExecutions(executionService.countTotal());
        stats.setSuccessfulExecutions(executionService.countSuccessful());
        stats.setFailedExecutions(executionService.countFailed());
        stats.setRecentExecutions(executionService.getRecentExecutions(10));

        List<DashboardStatsDTO.StatusCountDTO> jobsByStatus = jobService.getJobStatusCounts();
        stats.setJobsByStatus(jobsByStatus);

        List<DashboardStatsDTO.DayCountDTO> executionsByDay = executionService.countByDay().stream()
            .map(row -> new DashboardStatsDTO.DayCountDTO(row[0].toString(), ((Number) row[1]).longValue()))
            .collect(Collectors.toList());
        stats.setExecutionsByDay(executionsByDay);

        return stats;
    }
}
