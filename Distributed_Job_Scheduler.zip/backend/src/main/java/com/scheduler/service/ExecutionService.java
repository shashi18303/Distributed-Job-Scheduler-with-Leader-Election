package com.scheduler.service;

import com.scheduler.dto.JobExecutionDTO;
import com.scheduler.dto.PageResponse;
import com.scheduler.entity.Job;
import com.scheduler.entity.JobExecution;
import com.scheduler.repository.JobExecutionRepository;
import com.scheduler.repository.JobRepository;
import com.scheduler.repository.SchedulerNodeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ExecutionService {

    private final JobExecutionRepository executionRepository;
    private final JobRepository jobRepository;
    private final SchedulerNodeRepository nodeRepository;
    private final NodeService nodeService;

    public PageResponse<JobExecutionDTO> listExecutions(Long jobId, String status, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("startedAt").descending());
        Page<JobExecution> execPage;

        JobExecution.ExecutionStatus execStatus = null;
        if (status != null && !status.isBlank()) {
            try {
                execStatus = JobExecution.ExecutionStatus.valueOf(status.toUpperCase());
            } catch (IllegalArgumentException ignored) {}
        }

        if (jobId != null && execStatus != null) {
            execPage = executionRepository.findByJobIdAndStatus(jobId, execStatus, pageable);
        } else if (jobId != null) {
            execPage = executionRepository.findByJobId(jobId, pageable);
        } else if (execStatus != null) {
            execPage = executionRepository.findByStatus(execStatus, pageable);
        } else {
            execPage = executionRepository.findAll(pageable);
        }

        return PageResponse.from(execPage.map(this::toDTO));
    }

    public JobExecutionDTO getExecution(Long id) {
        return executionRepository.findById(id)
            .map(this::toDTO)
            .orElseThrow(() -> new RuntimeException("Execution not found: " + id));
    }

    @Transactional
    public JobExecutionDTO triggerJob(Long jobId) {
        Job job = jobRepository.findById(jobId)
            .orElseThrow(() -> new RuntimeException("Job not found: " + jobId));

        JobExecution exec = new JobExecution();
        exec.setJobId(jobId);
        exec.setNodeId(nodeService.getCurrentNodeDbId());
        exec.setStatus(JobExecution.ExecutionStatus.RUNNING);
        exec.setStartedAt(LocalDateTime.now());
        exec = executionRepository.save(exec);

        final Long execId = exec.getId();
        final Long nodeDbId = nodeService.getCurrentNodeDbId();

        new Thread(() -> simulateExecution(execId, job, nodeDbId)).start();

        return toDTO(exec);
    }

    @Transactional
    public void executeJob(Job job, Long nodeDbId) {
        JobExecution exec = new JobExecution();
        exec.setJobId(job.getId());
        exec.setNodeId(nodeDbId);
        exec.setStatus(JobExecution.ExecutionStatus.RUNNING);
        exec.setStartedAt(LocalDateTime.now());
        exec = executionRepository.save(exec);

        final Long execId = exec.getId();
        simulateExecution(execId, job, nodeDbId);
    }

    private void simulateExecution(Long execId, Job job, Long nodeDbId) {
        try {
            long startMs = System.currentTimeMillis();
            Thread.sleep(500 + (long)(Math.random() * 1500));

            boolean success = Math.random() > 0.15;
            long duration = System.currentTimeMillis() - startMs;

            executionRepository.findById(execId).ifPresent(e -> {
                e.setStatus(success ? JobExecution.ExecutionStatus.SUCCESS : JobExecution.ExecutionStatus.FAILED);
                e.setCompletedAt(LocalDateTime.now());
                e.setDurationMs(duration);
                e.setOutput(success ? "Job completed successfully. Processed items: " + (int)(Math.random() * 1000) : null);
                e.setErrorMessage(success ? null : "Simulated execution failure");
                executionRepository.save(e);
            });

            jobRepository.findById(job.getId()).ifPresent(j -> {
                j.setLastExecutedAt(LocalDateTime.now());
                j.setTotalExecutions(j.getTotalExecutions() + 1);
                if (success) {
                    j.setSuccessfulExecutions(j.getSuccessfulExecutions() + 1);
                } else {
                    j.setFailedExecutions(j.getFailedExecutions() + 1);
                }
                jobRepository.save(j);
            });

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            log.error("Error executing job {}", job.getId(), e);
        }
    }

    public List<JobExecutionDTO> getRecentExecutions(int count) {
        return executionRepository.findTop10ByOrderByStartedAtDesc().stream()
            .map(this::toDTO)
            .limit(count)
            .collect(Collectors.toList());
    }

    public long countTotal() { return executionRepository.count(); }
    public long countSuccessful() { return executionRepository.countSuccessful(); }
    public long countFailed() { return executionRepository.countFailed(); }

    public List<Object[]> countByDay() {
        return executionRepository.countByDay(LocalDateTime.now().minusDays(7));
    }

    private JobExecutionDTO toDTO(JobExecution exec) {
        String jobName = jobRepository.findById(exec.getJobId()).map(Job::getName).orElse(null);
        String nodeName = exec.getNodeId() != null
            ? nodeRepository.findById(exec.getNodeId()).map(n -> n.getHostname()).orElse(null)
            : null;
        return JobExecutionDTO.from(exec, jobName, nodeName);
    }
}
