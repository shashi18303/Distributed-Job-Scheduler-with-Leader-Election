package com.scheduler.service;

import com.scheduler.dto.NodeDTO;
import com.scheduler.entity.SchedulerNode;
import com.scheduler.repository.JobRepository;
import com.scheduler.repository.SchedulerNodeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.net.InetAddress;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class NodeService {

    private final SchedulerNodeRepository nodeRepository;
    private final JobRepository jobRepository;

    @Value("${server.port:8080}")
    private int serverPort;

    private String currentNodeId;
    private Long currentNodeDbId;

    @Transactional
    public SchedulerNode registerCurrentNode() {
        try {
            currentNodeId = UUID.randomUUID().toString().substring(0, 8);
            String hostname = InetAddress.getLocalHost().getHostName();
            String ipAddress = InetAddress.getLocalHost().getHostAddress();

            SchedulerNode node = new SchedulerNode();
            node.setNodeId(currentNodeId);
            node.setHostname(hostname);
            node.setIpAddress(ipAddress);
            node.setPort(serverPort);
            node.setStatus(SchedulerNode.NodeStatus.ACTIVE);
            node.setRegisteredAt(LocalDateTime.now());
            node.setLastHeartbeatAt(LocalDateTime.now());

            SchedulerNode saved = nodeRepository.save(node);
            currentNodeDbId = saved.getId();
            log.info("Registered node: {} ({})", currentNodeId, hostname);
            return saved;
        } catch (Exception e) {
            log.error("Failed to register node", e);
            throw new RuntimeException("Node registration failed", e);
        }
    }

    @Transactional
    public void sendHeartbeat() {
        if (currentNodeId == null) return;
        nodeRepository.findByNodeId(currentNodeId).ifPresent(node -> {
            node.setLastHeartbeatAt(LocalDateTime.now());
            node.setStatus(SchedulerNode.NodeStatus.ACTIVE);
            nodeRepository.save(node);
        });
    }

    @Transactional
    public void detectAndMarkFailedNodes(long timeoutMs) {
        LocalDateTime timeout = LocalDateTime.now().minusNanos(timeoutMs * 1_000_000L);
        int marked = nodeRepository.markTimedOutNodes(timeout);
        if (marked > 0) {
            log.warn("Marked {} node(s) as FAILED due to heartbeat timeout", marked);
        }
    }

    public List<NodeDTO> getAllNodes() {
        return nodeRepository.findAll().stream()
            .map(node -> {
                int activeJobs = 0;
                if (node.getId() != null) {
                    activeJobs = (int) jobRepository.findByStatus(com.scheduler.entity.Job.JobStatus.ACTIVE)
                        .stream().filter(j -> node.getId().equals(j.getAssignedNodeId())).count();
                }
                return NodeDTO.from(node, activeJobs);
            })
            .collect(Collectors.toList());
    }

    public Optional<NodeDTO> getLeaderNode() {
        return nodeRepository.findByLeaderTrue()
            .map(node -> NodeDTO.from(node, 0));
    }

    public String getCurrentNodeId() {
        return currentNodeId;
    }

    public Long getCurrentNodeDbId() {
        return currentNodeDbId;
    }

    @Transactional
    public void markNodeAsLeader(String nodeId) {
        nodeRepository.findAll().forEach(n -> {
            n.setLeader(false);
            nodeRepository.save(n);
        });
        nodeRepository.findByNodeId(nodeId).ifPresent(n -> {
            n.setLeader(true);
            nodeRepository.save(n);
        });
    }

    @Transactional
    public void resignLeadership() {
        if (currentNodeId != null) {
            nodeRepository.findByNodeId(currentNodeId).ifPresent(n -> {
                n.setLeader(false);
                nodeRepository.save(n);
            });
        }
    }

    public long countActiveNodes() {
        return nodeRepository.countActiveNodes();
    }

    public long countTotalNodes() {
        return nodeRepository.count();
    }
}
