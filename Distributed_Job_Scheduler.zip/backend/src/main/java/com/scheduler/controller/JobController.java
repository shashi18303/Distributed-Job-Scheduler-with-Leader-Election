package com.scheduler.controller;

import com.scheduler.dto.JobDTO;
import com.scheduler.dto.JobExecutionDTO;
import com.scheduler.dto.PageResponse;
import com.scheduler.service.ExecutionService;
import com.scheduler.service.JobService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/jobs")
@RequiredArgsConstructor
public class JobController {

    private final JobService jobService;
    private final ExecutionService executionService;

    @GetMapping
    public ResponseEntity<PageResponse<JobDTO>> listJobs(
        @RequestParam(required = false) String status,
        @RequestParam(defaultValue = "0") int page,
        @RequestParam(defaultValue = "20") int size
    ) {
        return ResponseEntity.ok(jobService.listJobs(status, page, size));
    }

    @PostMapping
    public ResponseEntity<JobDTO> createJob(@RequestBody Map<String, Object> body) {
        return ResponseEntity.status(HttpStatus.CREATED).body(jobService.createJob(body));
    }

    @GetMapping("/{id}")
    public ResponseEntity<JobDTO> getJob(@PathVariable Long id) {
        return ResponseEntity.ok(jobService.getJob(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<JobDTO> updateJob(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        return ResponseEntity.ok(jobService.updateJob(id, body));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteJob(@PathVariable Long id) {
        jobService.deleteJob(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}/pause")
    public ResponseEntity<JobDTO> pauseJob(@PathVariable Long id) {
        return ResponseEntity.ok(jobService.pauseJob(id));
    }

    @PutMapping("/{id}/resume")
    public ResponseEntity<JobDTO> resumeJob(@PathVariable Long id) {
        return ResponseEntity.ok(jobService.resumeJob(id));
    }

    @PostMapping("/{id}/trigger")
    public ResponseEntity<JobExecutionDTO> triggerJob(@PathVariable Long id) {
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(executionService.triggerJob(id));
    }
}
