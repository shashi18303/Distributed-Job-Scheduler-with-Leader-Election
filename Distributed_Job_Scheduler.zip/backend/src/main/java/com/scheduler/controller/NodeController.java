package com.scheduler.controller;

import com.scheduler.dto.NodeDTO;
import com.scheduler.service.NodeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/nodes")
@RequiredArgsConstructor
public class NodeController {

    private final NodeService nodeService;

    @GetMapping
    public ResponseEntity<List<NodeDTO>> listNodes() {
        return ResponseEntity.ok(nodeService.getAllNodes());
    }

    @GetMapping("/leader")
    public ResponseEntity<NodeDTO> getLeader() {
        return nodeService.getLeaderNode()
            .map(ResponseEntity::ok)
            .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
