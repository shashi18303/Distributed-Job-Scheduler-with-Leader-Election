package com.scheduler.controller;

import com.scheduler.dto.JobExecutionDTO;
import com.scheduler.dto.PageResponse;
import com.scheduler.service.ExecutionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/executions")
@RequiredArgsConstructor
public class ExecutionController {

    private final ExecutionService executionService;

    @GetMapping
    public ResponseEntity<PageResponse<JobExecutionDTO>> listExecutions(
        @RequestParam(required = false) Long jobId,
        @RequestParam(required = false) String status,
        @RequestParam(defaultValue = "0") int page,
        @RequestParam(defaultValue = "20") int size
    ) {
        return ResponseEntity.ok(executionService.listExecutions(jobId, status, page, size));
    }

    @GetMapping("/{id}")
    public ResponseEntity<JobExecutionDTO> getExecution(@PathVariable Long id) {
        return ResponseEntity.ok(executionService.getExecution(id));
    }
}
