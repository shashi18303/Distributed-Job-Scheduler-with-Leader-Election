package com.scheduler.service;

import com.scheduler.entity.LeaderElection;
import com.scheduler.repository.LeaderElectionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("LeaderElectionService Unit Tests")
class LeaderElectionServiceTest {

    @Mock
    private LeaderElectionRepository leaderElectionRepository;

    @Mock
    private NodeService nodeService;

    @InjectMocks
    private LeaderElectionService leaderElectionService;

    private static final String NODE_ID = "node-abc-123";
    private static final String OTHER_NODE = "node-xyz-999";

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(leaderElectionService, "leaderLeaseMs", 10000L);
        when(nodeService.getCurrentNodeId()).thenReturn(NODE_ID);
    }

    @Test
    @DisplayName("tryAcquireLeadership - acquires lock when no leader exists")
    void tryAcquireLeadership_noExistingLock_acquiresSuccessfully() {
        when(leaderElectionRepository.findByLockNameForUpdate(anyString()))
            .thenReturn(Optional.empty());
        when(leaderElectionRepository.save(any(LeaderElection.class)))
            .thenAnswer(inv -> inv.getArgument(0));

        boolean result = leaderElectionService.tryAcquireLeadership();

        assertThat(result).isTrue();
        assertThat(leaderElectionService.isCurrentlyLeader()).isTrue();
        verify(leaderElectionRepository).save(any(LeaderElection.class));
    }

    @Test
    @DisplayName("tryAcquireLeadership - renews own lease when already leader")
    void tryAcquireLeadership_selfIsLeader_renewsLease() {
        LeaderElection lock = new LeaderElection();
        lock.setLockName("LEADER_LOCK");
        lock.setNodeId(NODE_ID);
        lock.setExpiresAt(LocalDateTime.now().plusSeconds(5));

        when(leaderElectionRepository.findByLockNameForUpdate(anyString()))
            .thenReturn(Optional.of(lock));
        when(leaderElectionRepository.save(any(LeaderElection.class)))
            .thenAnswer(inv -> inv.getArgument(0));

        boolean result = leaderElectionService.tryAcquireLeadership();

        assertThat(result).isTrue();
        verify(leaderElectionRepository).save(argThat(l ->
            l.getNodeId().equals(NODE_ID) && l.getExpiresAt().isAfter(LocalDateTime.now())
        ));
    }

    @Test
    @DisplayName("tryAcquireLeadership - does NOT steal active lease from other node")
    void tryAcquireLeadership_otherNodeActiveLeader_doesNotSteal() {
        LeaderElection lock = new LeaderElection();
        lock.setNodeId(OTHER_NODE);
        lock.setExpiresAt(LocalDateTime.now().plusSeconds(8));

        when(leaderElectionRepository.findByLockNameForUpdate(anyString()))
            .thenReturn(Optional.of(lock));

        boolean result = leaderElectionService.tryAcquireLeadership();

        assertThat(result).isFalse();
        verify(leaderElectionRepository, never()).save(any());
    }

    @Test
    @DisplayName("tryAcquireLeadership - steals expired lease from other node")
    void tryAcquireLeadership_expiredLeaseFromOtherNode_stealsLeadership() {
        LeaderElection lock = new LeaderElection();
        lock.setNodeId(OTHER_NODE);
        lock.setExpiresAt(LocalDateTime.now().minusSeconds(5));

        when(leaderElectionRepository.findByLockNameForUpdate(anyString()))
            .thenReturn(Optional.of(lock));
        when(leaderElectionRepository.save(any(LeaderElection.class)))
            .thenAnswer(inv -> inv.getArgument(0));

        boolean result = leaderElectionService.tryAcquireLeadership();

        assertThat(result).isTrue();
        verify(leaderElectionRepository).save(argThat(l -> l.getNodeId().equals(NODE_ID)));
    }

    @Test
    @DisplayName("tryAcquireLeadership - returns false when nodeId is null")
    void tryAcquireLeadership_nullNodeId_returnsFalse() {
        when(nodeService.getCurrentNodeId()).thenReturn(null);

        boolean result = leaderElectionService.tryAcquireLeadership();

        assertThat(result).isFalse();
        verify(leaderElectionRepository, never()).findByLockNameForUpdate(any());
    }

    @Test
    @DisplayName("releaseLeadership - clears leader state")
    void releaseLeadership_whenLeader_clearsLeaderState() {
        LeaderElection lock = new LeaderElection();
        lock.setNodeId(NODE_ID);
        lock.setExpiresAt(LocalDateTime.now().plusSeconds(5));

        when(leaderElectionRepository.findByLockNameForUpdate(anyString()))
            .thenReturn(Optional.empty());
        when(leaderElectionRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));
        leaderElectionService.tryAcquireLeadership();

        when(leaderElectionRepository.findByLockName(anyString()))
            .thenReturn(Optional.of(lock));

        leaderElectionService.releaseLeadership();

        assertThat(leaderElectionService.isCurrentlyLeader()).isFalse();
    }

    @Test
    @DisplayName("isCurrentlyLeader - returns false by default before any election")
    void isCurrentlyLeader_defaultState_returnsFalse() {
        assertThat(leaderElectionService.isCurrentlyLeader()).isFalse();
    }
}
