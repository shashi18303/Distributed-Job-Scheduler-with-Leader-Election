package com.scheduler.service;

import com.scheduler.dto.JobDTO;
import com.scheduler.dto.PageResponse;
import com.scheduler.entity.Job;
import com.scheduler.repository.JobRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("JobService Unit Tests")
class JobServiceTest {

    @Mock
    private JobRepository jobRepository;

    @InjectMocks
    private JobService jobService;

    private Job sampleJob;

    @BeforeEach
    void setUp() {
        sampleJob = new Job();
        sampleJob.setId(1L);
        sampleJob.setName("Test Job");
        sampleJob.setDescription("A test job");
        sampleJob.setCronExpression("0/5 * * * * ?");
        sampleJob.setJobType(Job.JobType.HTTP_REQUEST);
        sampleJob.setStatus(Job.JobStatus.ACTIVE);
        sampleJob.setCreatedAt(LocalDateTime.now());
        sampleJob.setUpdatedAt(LocalDateTime.now());
    }

    @Test
    @DisplayName("listJobs - returns paginated jobs without status filter")
    void listJobs_noFilter_returnsAll() {
        Page<Job> page = new PageImpl<>(List.of(sampleJob), PageRequest.of(0, 20), 1);
        when(jobRepository.findAll(any(Pageable.class))).thenReturn(page);

        PageResponse<JobDTO> result = jobService.listJobs(null, 0, 20);

        assertThat(result).isNotNull();
        assertThat(result.getContent()).hasSize(1);
        assertThat(result.getContent().get(0).getName()).isEqualTo("Test Job");
        verify(jobRepository).findAll(any(Pageable.class));
        verify(jobRepository, never()).findByStatus(any(), any());
    }

    @Test
    @DisplayName("listJobs - filters by ACTIVE status correctly")
    void listJobs_withActiveStatus_filtersCorrectly() {
        Page<Job> page = new PageImpl<>(List.of(sampleJob));
        when(jobRepository.findByStatus(eq(Job.JobStatus.ACTIVE), any(Pageable.class))).thenReturn(page);

        PageResponse<JobDTO> result = jobService.listJobs("ACTIVE", 0, 20);

        assertThat(result.getContent()).hasSize(1);
        verify(jobRepository).findByStatus(eq(Job.JobStatus.ACTIVE), any(Pageable.class));
    }

    @Test
    @DisplayName("listJobs - falls back to findAll on invalid status")
    void listJobs_withInvalidStatus_fallsBackToAll() {
        Page<Job> page = new PageImpl<>(List.of(sampleJob));
        when(jobRepository.findAll(any(Pageable.class))).thenReturn(page);

        PageResponse<JobDTO> result = jobService.listJobs("INVALID_STATUS", 0, 20);

        assertThat(result.getContent()).hasSize(1);
        verify(jobRepository).findAll(any(Pageable.class));
    }

    @Test
    @DisplayName("createJob - persists and returns new job")
    void createJob_validPayload_savesJob() {
        when(jobRepository.save(any(Job.class))).thenReturn(sampleJob);

        Map<String, Object> payload = Map.of(
            "name", "Test Job",
            "description", "A test job",
            "cronExpression", "0/5 * * * * ?",
            "jobType", "HTTP_REQUEST"
        );

        JobDTO result = jobService.createJob(payload);

        assertThat(result).isNotNull();
        assertThat(result.getName()).isEqualTo("Test Job");
        assertThat(result.getStatus()).isEqualTo("ACTIVE");
        verify(jobRepository).save(any(Job.class));
    }

    @Test
    @DisplayName("createJob - defaults to CUSTOM job type when unknown type provided")
    void createJob_unknownJobType_defaultsToCustom() {
        Job customJob = new Job();
        customJob.setId(2L);
        customJob.setName("Custom Job");
        customJob.setJobType(Job.JobType.CUSTOM);
        customJob.setStatus(Job.JobStatus.ACTIVE);
        customJob.setCreatedAt(LocalDateTime.now());
        customJob.setUpdatedAt(LocalDateTime.now());
        when(jobRepository.save(any(Job.class))).thenReturn(customJob);

        Map<String, Object> payload = Map.of(
            "name", "Custom Job",
            "cronExpression", "0 * * * * ?",
            "jobType", "UNKNOWN_TYPE"
        );

        JobDTO result = jobService.createJob(payload);
        assertThat(result.getJobType()).isEqualTo("CUSTOM");
    }

    @Test
    @DisplayName("getJob - returns job when found")
    void getJob_existingId_returnsJob() {
        when(jobRepository.findById(1L)).thenReturn(Optional.of(sampleJob));

        JobDTO result = jobService.getJob(1L);

        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(1L);
    }

    @Test
    @DisplayName("getJob - throws when job not found")
    void getJob_nonExistingId_throws() {
        when(jobRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> jobService.getJob(99L))
            .isInstanceOf(RuntimeException.class);
    }

    @Test
    @DisplayName("pauseJob - sets status to PAUSED")
    void pauseJob_activeJob_setsPaused() {
        when(jobRepository.findById(1L)).thenReturn(Optional.of(sampleJob));
        when(jobRepository.save(any(Job.class))).thenReturn(sampleJob);

        JobDTO result = jobService.pauseJob(1L);

        assertThat(result).isNotNull();
        verify(jobRepository).save(argThat(j -> j.getStatus() == Job.JobStatus.PAUSED));
    }

    @Test
    @DisplayName("resumeJob - sets status to ACTIVE")
    void resumeJob_pausedJob_setsActive() {
        sampleJob.setStatus(Job.JobStatus.PAUSED);
        when(jobRepository.findById(1L)).thenReturn(Optional.of(sampleJob));
        when(jobRepository.save(any(Job.class))).thenReturn(sampleJob);

        JobDTO result = jobService.resumeJob(1L);

        assertThat(result).isNotNull();
        verify(jobRepository).save(argThat(j -> j.getStatus() == Job.JobStatus.ACTIVE));
    }

    @Test
    @DisplayName("deleteJob - calls repository delete")
    void deleteJob_existingJob_deletesSuccessfully() {
        when(jobRepository.findById(1L)).thenReturn(Optional.of(sampleJob));
        doNothing().when(jobRepository).delete(sampleJob);

        jobService.deleteJob(1L);

        verify(jobRepository).delete(sampleJob);
    }

    @Test
    @DisplayName("countActive - returns count from repository")
    void countActive_returnsCorrectCount() {
        when(jobRepository.countActiveJobs()).thenReturn(3L);

        long count = jobService.countActive();

        assertThat(count).isEqualTo(3L);
    }
}
