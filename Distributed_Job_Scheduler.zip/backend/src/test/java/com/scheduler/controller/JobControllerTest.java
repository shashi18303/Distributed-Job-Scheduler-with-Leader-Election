package com.scheduler.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scheduler.dto.JobDTO;
import com.scheduler.dto.PageResponse;
import com.scheduler.service.JobService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@DisplayName("JobController Integration Tests")
class JobControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private JobService jobService;

    @Autowired
    private ObjectMapper objectMapper;

    private JobDTO buildSampleJob(long id, String name, String status) {
        JobDTO dto = new JobDTO();
        dto.setId(id);
        dto.setName(name);
        dto.setDescription("Test description");
        dto.setCronExpression("0/30 * * * * ?");
        dto.setJobType("HTTP_REQUEST");
        dto.setStatus(status);
        dto.setCreatedAt(LocalDateTime.now());
        dto.setUpdatedAt(LocalDateTime.now());
        return dto;
    }

    @Test
    @WithMockUser(username = "admin", roles = {"USER"})
    @DisplayName("GET /api/jobs - returns paginated job list")
    void listJobs_authenticated_returnsOk() throws Exception {
        PageResponse<JobDTO> page = new PageResponse<>();
        page.setContent(List.of(buildSampleJob(1L, "Health Check", "ACTIVE")));
        page.setPage(0);
        page.setSize(20);
        page.setTotalElements(1L);
        page.setTotalPages(1);

        when(jobService.listJobs(any(), anyInt(), anyInt())).thenReturn(page);

        mockMvc.perform(get("/api/jobs")
                .param("page", "0")
                .param("size", "20")
                .accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.content").isArray())
            .andExpect(jsonPath("$.content[0].name").value("Health Check"))
            .andExpect(jsonPath("$.totalElements").value(1));
    }

    @Test
    @DisplayName("GET /api/jobs - returns 401 when not authenticated")
    void listJobs_unauthenticated_returns401() throws Exception {
        mockMvc.perform(get("/api/jobs"))
            .andExpect(status().isUnauthorized());
    }

    @Test
    @WithMockUser(username = "admin", roles = {"USER"})
    @DisplayName("POST /api/jobs - creates job and returns 201")
    void createJob_validPayload_returns201() throws Exception {
        JobDTO created = buildSampleJob(5L, "New Job", "ACTIVE");
        when(jobService.createJob(anyMap())).thenReturn(created);

        Map<String, Object> payload = Map.of(
            "name", "New Job",
            "cronExpression", "0 * * * * ?",
            "jobType", "HTTP_REQUEST"
        );

        mockMvc.perform(post("/api/jobs")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(payload)))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.name").value("New Job"))
            .andExpect(jsonPath("$.status").value("ACTIVE"));
    }

    @Test
    @WithMockUser(username = "admin", roles = {"USER"})
    @DisplayName("POST /api/jobs/:id/pause - pauses job")
    void pauseJob_validId_returnsUpdatedJob() throws Exception {
        JobDTO paused = buildSampleJob(1L, "Health Check", "PAUSED");
        when(jobService.pauseJob(1L)).thenReturn(paused);

        mockMvc.perform(post("/api/jobs/1/pause"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status").value("PAUSED"));
    }

    @Test
    @WithMockUser(username = "admin", roles = {"USER"})
    @DisplayName("DELETE /api/jobs/:id - deletes job successfully")
    void deleteJob_validId_returns204() throws Exception {
        doNothing().when(jobService).deleteJob(1L);

        mockMvc.perform(delete("/api/jobs/1"))
            .andExpect(status().isNoContent());
    }
}
