import React, { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import {
  Activity, LayoutDashboard, Server, LogOut,
  TerminalSquare, CheckCircle, XCircle, Cpu,
  GitBranch, Zap
} from "lucide-react";
import { useLogout, useGetMe, getGetMeQueryKey, useHealthCheck, getHealthCheckQueryKey, useGetStats, getGetStatsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

const PAGE_TITLES: Record<string, string> = {
  "/": "System Overview",
  "/dashboard": "System Overview",
  "/jobs": "Jobs Registry",
  "/jobs/new": "Create New Job",
  "/executions": "Execution Logs",
  "/nodes": "Cluster Topology",
};

export function Layout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [time, setTime] = useState(new Date());
  const [uptime, setUptime] = useState(0);

  useEffect(() => {
    const start = Date.now();
    const t = setInterval(() => {
      setTime(new Date());
      setUptime(Math.floor((Date.now() - start) / 1000));
    }, 1000);
    return () => clearInterval(t);
  }, []);

  const { data: me } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const { data: health } = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey(), refetchInterval: 10000 } });
  const { data: stats } = useGetStats({ query: { queryKey: getGetStatsQueryKey(), refetchInterval: 5000 } });

  const logout = useLogout({
    mutation: {
      onSuccess: () => {
        queryClient.clear();
        setLocation("/login");
      }
    }
  });

  const navItems = [
    { label: "Dashboard", href: "/", icon: LayoutDashboard, hint: "Overview" },
    { label: "Jobs", href: "/jobs", icon: TerminalSquare, hint: stats ? `${stats.activeJobs} active` : "" },
    { label: "Executions", href: "/executions", icon: Activity, hint: "Logs" },
    { label: "Nodes", href: "/nodes", icon: Server, hint: stats ? `${stats.activeNodes} nodes` : "" },
  ];

  const pageTitle = Object.entries(PAGE_TITLES).find(([k]) =>
    location === k || (k !== "/" && location.startsWith(k))
  )?.[1] ?? location.replace(/\//g, " / ").substring(1);

  const uptimeStr = `${Math.floor(uptime / 3600).toString().padStart(2,"0")}:${Math.floor((uptime % 3600)/60).toString().padStart(2,"0")}:${(uptime % 60).toString().padStart(2,"0")}`;

  const apiOk = health?.status === "UP";

  return (
    <div className="flex min-h-screen bg-background text-foreground font-mono">
      <aside className="w-60 border-r border-border bg-[hsl(var(--sidebar))] flex flex-col shrink-0">
        <div className="h-14 flex items-center px-4 border-b border-border gap-2.5">
          <div className="relative">
            <Cpu className="w-5 h-5 text-primary" />
            <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
          </div>
          <div>
            <div className="text-sm font-bold tracking-widest text-primary leading-none">SCHEDULER_OS</div>
            <div className="text-[9px] text-muted-foreground tracking-wider mt-0.5">Java 21 · Spring Boot 3</div>
          </div>
        </div>

        <div className="px-3 py-3 border-b border-border space-y-0.5">
          {navItems.map((item) => {
            const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center justify-between px-3 py-2 rounded text-sm transition-all duration-150 group ${
                  isActive
                    ? "bg-primary/10 text-primary border border-primary/20"
                    : "text-muted-foreground hover:bg-accent hover:text-foreground border border-transparent"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  {isActive && <div className="w-1 h-4 rounded-full bg-primary absolute left-3" />}
                  <item.icon className={`w-4 h-4 ${isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground"}`} />
                  <span className="font-medium">{item.label}</span>
                </div>
                {item.hint && (
                  <span className="text-[10px] text-muted-foreground/60">{item.hint}</span>
                )}
              </Link>
            );
          })}
        </div>

        <div className="px-3 py-3 space-y-2 border-b border-border">
          <div className="text-[9px] text-muted-foreground tracking-widest mb-2 px-1">CLUSTER STATUS</div>
          <div className="grid grid-cols-2 gap-1.5 text-[10px] font-mono">
            <div className="bg-background/60 rounded px-2 py-1.5 border border-border/60">
              <div className="text-muted-foreground mb-0.5">JOBS</div>
              <div className="text-foreground font-bold">{stats?.activeJobs ?? "—"}<span className="text-muted-foreground font-normal">/{stats?.totalJobs ?? "—"}</span></div>
            </div>
            <div className="bg-background/60 rounded px-2 py-1.5 border border-border/60">
              <div className="text-muted-foreground mb-0.5">NODES</div>
              <div className="text-foreground font-bold">{stats?.activeNodes ?? "—"}<span className="text-muted-foreground font-normal">/{stats?.totalNodes ?? "—"}</span></div>
            </div>
            <div className="bg-background/60 rounded px-2 py-1.5 border border-border/60 col-span-2">
              <div className="text-muted-foreground mb-0.5">SUCCESS RATE</div>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-1 rounded bg-border overflow-hidden">
                  <div
                    className="h-full rounded bg-green-500 transition-all duration-500"
                    style={{
                      width: stats && stats.totalExecutions > 0
                        ? `${Math.round((stats.successfulExecutions / stats.totalExecutions) * 100)}%`
                        : "0%"
                    }}
                  />
                </div>
                <span className="text-green-500 font-bold">
                  {stats && stats.totalExecutions > 0 ? `${Math.round((stats.successfulExecutions / stats.totalExecutions) * 100)}%` : "—"}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex-1" />

        <div className="px-3 py-3 border-t border-border space-y-2">
          <div className="flex items-center justify-between text-[10px]">
            <div className="flex items-center gap-1.5">
              <div className={`w-1.5 h-1.5 rounded-full ${apiOk ? "bg-green-500 animate-pulse" : "bg-destructive"}`} />
              <span className={apiOk ? "text-green-500" : "text-destructive"}>{apiOk ? "API ONLINE" : "API ERROR"}</span>
            </div>
            <span className="text-muted-foreground/60 tabular-nums">UP {uptimeStr}</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center">
                <span className="text-[9px] text-primary font-bold">{(me?.username?.[0] ?? "A").toUpperCase()}</span>
              </div>
              <span className="text-xs text-foreground">{me?.username ?? "admin"}</span>
            </div>
            <button
              onClick={() => logout.mutate()}
              className="p-1.5 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded transition-colors"
              title="Logout"
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </aside>

      <main className="flex-1 flex flex-col h-screen overflow-hidden min-w-0">
        <header className="h-14 border-b border-border bg-card/30 backdrop-blur-sm flex items-center justify-between px-6 shrink-0">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-muted-foreground/40">
              <GitBranch className="w-3 h-3" />
              <span className="text-[10px] tracking-wider">main</span>
            </div>
            <span className="text-muted-foreground/30">/</span>
            <h1 className="text-sm font-medium tracking-widest text-foreground uppercase">
              {pageTitle}
            </h1>
          </div>
          <div className="flex items-center gap-4 text-[10px] text-muted-foreground font-mono">
            {stats?.leaderNode && (
              <div className="flex items-center gap-1.5 border border-primary/20 bg-primary/5 px-2 py-1 rounded">
                <Zap className="w-2.5 h-2.5 text-primary" />
                <span className="text-primary">LEADER:</span>
                <span className="text-foreground">{stats.leaderNode}</span>
              </div>
            )}
            <span className="tabular-nums text-muted-foreground/50">{time.toISOString()}</span>
          </div>
        </header>

        <div className="flex-1 overflow-auto p-6">
          {children}
        </div>
      </main>
    </div>
  );
}
