import React, { useState } from "react";
import { Link, useParams } from "wouter";
import {
  useGetJob, getGetJobQueryKey,
  useListExecutions, getListExecutionsQueryKey,
  useTriggerJob, useUpdateJob
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import {
  Activity, TerminalSquare, ArrowLeft, Play, Clock,
  CheckCircle, XCircle, Edit, Save, X, Zap, Calendar, Hash
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

function InfoRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="bg-muted/20 rounded px-3 py-2.5 border border-border/50">
      <div className="text-[9px] uppercase tracking-widest text-muted-foreground mb-1">{label}</div>
      <div className="font-mono text-sm text-foreground">{value}</div>
    </div>
  );
}

export default function JobDetail() {
  const { id } = useParams<{ id: string }>();
  const jobId = parseInt(id || "0", 10);
  const queryClient = useQueryClient();
  const [page, setPage] = useState(0);
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({ description: "", cronExpression: "", payload: "" });

  const { data: job, isLoading: isLoadingJob } = useGetJob(jobId, {
    query: {
      queryKey: getGetJobQueryKey(jobId),
      enabled: !!jobId && !isNaN(jobId),
      refetchInterval: isEditing ? false : 5000
    }
  });

  const execParams = { jobId, page, size: 10 };
  const { data: execs, isLoading: isLoadingExecs } = useListExecutions(execParams, {
    query: {
      queryKey: getListExecutionsQueryKey(execParams),
      enabled: !!jobId && !isNaN(jobId),
      refetchInterval: 5000
    }
  });

  const triggerJob = useTriggerJob({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetJobQueryKey(jobId) });
        queryClient.invalidateQueries({ queryKey: getListExecutionsQueryKey(execParams) });
      }
    }
  });

  const updateJob = useUpdateJob({
    mutation: {
      onSuccess: () => {
        setIsEditing(false);
        queryClient.invalidateQueries({ queryKey: getGetJobQueryKey(jobId) });
      }
    }
  });

  const handleEditClick = () => {
    if (job) {
      setEditForm({
        description: job.description || "",
        cronExpression: job.cronExpression || "",
        payload: job.payload || ""
      });
      setIsEditing(true);
    }
  };

  const handleSaveClick = () => {
    if (job) updateJob.mutate({ id: job.id, data: editForm });
  };

  if (isLoadingJob || !job) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="flex flex-col items-center gap-4 text-primary">
          <div className="relative">
            <Activity className="w-7 h-7 animate-pulse" />
            <div className="absolute inset-0 border border-primary/30 rounded animate-ping" />
          </div>
          <span className="tracking-widest text-sm text-muted-foreground">LOADING JOB DATA...</span>
        </div>
      </div>
    );
  }

  const successRate = (job.totalExecutions || 0) > 0
    ? Math.round(((job.successfulExecutions || 0) / (job.totalExecutions || 1)) * 100) : 0;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <Link href="/jobs" className="p-1.5 text-muted-foreground hover:text-primary hover:bg-primary/10 rounded transition-colors">
            <ArrowLeft className="w-4 h-4" />
          </Link>
          <div className="flex items-center gap-2.5">
            <TerminalSquare className="w-4 h-4 text-primary" />
            <h2 className="text-base font-bold tracking-widest text-primary">{job.name}</h2>
            <Badge
              variant="outline"
              className={
                job.status === "ACTIVE" ? "border-green-500/40 text-green-500 bg-green-500/10 text-[9px]" :
                job.status === "PAUSED" ? "border-yellow-500/40 text-yellow-500 bg-yellow-500/10 text-[9px]" :
                "border-destructive/40 text-destructive bg-destructive/10 text-[9px]"
              }
            >
              {job.status}
            </Badge>
          </div>
        </div>

        <Button
          onClick={() => triggerJob.mutate({ id: job.id })}
          disabled={triggerJob.isPending}
          size="sm"
          className="gap-2 tracking-widest bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_15px_rgba(14,165,233,0.2)] hover:shadow-[0_0_25px_rgba(14,165,233,0.35)] transition-all"
        >
          <Zap className="w-3.5 h-3.5" />
          {triggerJob.isPending ? "TRIGGERING..." : "MANUAL_TRIGGER"}
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="bg-card border-border lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-3 pt-4 px-5">
            <CardTitle className="text-[10px] uppercase tracking-widest text-muted-foreground flex items-center gap-2">
              <Hash className="w-3 h-3" /> Configuration
            </CardTitle>
            {!isEditing ? (
              <Button variant="ghost" size="sm" onClick={handleEditClick} className="h-7 gap-1.5 text-xs text-muted-foreground hover:text-primary">
                <Edit className="w-3 h-3" /> Edit
              </Button>
            ) : (
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="sm" onClick={() => setIsEditing(false)} className="h-7 text-xs text-muted-foreground">
                  <X className="w-3 h-3 mr-1" /> Cancel
                </Button>
                <Button
                  size="sm"
                  onClick={handleSaveClick}
                  disabled={updateJob.isPending}
                  className="h-7 text-xs bg-green-600 hover:bg-green-700 text-white gap-1.5"
                >
                  <Save className="w-3 h-3" />
                  {updateJob.isPending ? "Saving..." : "Save"}
                </Button>
              </div>
            )}
          </CardHeader>
          <CardContent className="px-5 pb-5 space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <InfoRow label="Job ID" value={`#${job.id}`} />
              <InfoRow label="Job Type" value={job.jobType} />
              <div className="col-span-2 sm:col-span-1">
                {isEditing ? (
                  <div className="bg-muted/20 rounded px-3 py-2.5 border border-primary/30">
                    <div className="text-[9px] uppercase tracking-widest text-muted-foreground mb-1">Cron Schedule</div>
                    <Input
                      value={editForm.cronExpression}
                      onChange={e => setEditForm(f => ({ ...f, cronExpression: e.target.value }))}
                      className="font-mono text-sm h-7 bg-background border-border focus:border-primary/50 px-2"
                    />
                  </div>
                ) : (
                  <InfoRow label="Cron Schedule" value={
                    <span className="inline-flex items-center gap-1.5">
                      <Clock className="w-3 h-3 text-primary/60" />
                      {job.cronExpression}
                    </span>
                  } />
                )}
              </div>
              <InfoRow label="Assigned Node" value={job.assignedNodeId || "UNASSIGNED"} />
            </div>

            <div>
              {isEditing ? (
                <div className="bg-muted/20 rounded px-3 py-2.5 border border-primary/30">
                  <div className="text-[9px] uppercase tracking-widest text-muted-foreground mb-1">Description</div>
                  <Input
                    value={editForm.description}
                    onChange={e => setEditForm(f => ({ ...f, description: e.target.value }))}
                    className="text-sm h-7 bg-background border-border focus:border-primary/50 px-2"
                  />
                </div>
              ) : (
                <InfoRow label="Description" value={
                  job.description || <span className="text-muted-foreground italic text-xs">No description</span>
                } />
              )}
            </div>

            <div>
              {isEditing ? (
                <div className="bg-muted/20 rounded px-3 py-2.5 border border-primary/30">
                  <div className="text-[9px] uppercase tracking-widest text-muted-foreground mb-1">Payload (JSON)</div>
                  <Textarea
                    value={editForm.payload}
                    onChange={e => setEditForm(f => ({ ...f, payload: e.target.value }))}
                    className="font-mono text-xs min-h-[80px] bg-background border-border focus:border-primary/50 resize-none"
                  />
                </div>
              ) : job.payload ? (
                <div className="bg-muted/20 rounded px-3 py-2.5 border border-border/50">
                  <div className="text-[9px] uppercase tracking-widest text-muted-foreground mb-2">Payload</div>
                  <pre className="text-xs bg-black/50 text-green-400 p-3 rounded border border-border/40 overflow-x-auto max-h-40">
                    {job.payload}
                  </pre>
                </div>
              ) : null}
            </div>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card className="bg-card border-border">
            <CardHeader className="pb-2 pt-4 px-5">
              <CardTitle className="text-[10px] uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                <Calendar className="w-3 h-3" /> Schedule
              </CardTitle>
            </CardHeader>
            <CardContent className="px-5 pb-4 space-y-2">
              <InfoRow label="Next Execution" value={
                job.nextExecutionAt ? new Date(job.nextExecutionAt).toLocaleString() : "N/A"
              } />
              <InfoRow label="Last Execution" value={
                job.lastExecutedAt ? new Date(job.lastExecutedAt).toLocaleString() : "NEVER"
              } />
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="pb-2 pt-4 px-5">
              <CardTitle className="text-[10px] uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                <Activity className="w-3 h-3" /> Statistics
              </CardTitle>
            </CardHeader>
            <CardContent className="px-5 pb-4 space-y-3">
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="bg-muted/20 rounded p-2 border border-border/50">
                  <div className="text-xl font-bold tabular-nums">{job.totalExecutions || 0}</div>
                  <div className="text-[9px] text-muted-foreground uppercase">Total</div>
                </div>
                <div className="bg-muted/20 rounded p-2 border border-green-500/20">
                  <div className="text-xl font-bold text-green-500 tabular-nums">{job.successfulExecutions || 0}</div>
                  <div className="text-[9px] text-muted-foreground uppercase">OK</div>
                </div>
                <div className="bg-muted/20 rounded p-2 border border-destructive/20">
                  <div className="text-xl font-bold text-destructive tabular-nums">{job.failedExecutions || 0}</div>
                  <div className="text-[9px] text-muted-foreground uppercase">Fail</div>
                </div>
              </div>
              <div className="space-y-1">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-muted-foreground">SUCCESS RATE</span>
                  <span className="text-green-500 font-bold">{successRate}%</span>
                </div>
                <div className="h-1.5 rounded bg-border overflow-hidden">
                  <div
                    className="h-full rounded bg-gradient-to-r from-green-600 to-green-400 transition-all duration-500"
                    style={{ width: `${successRate}%` }}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card className="bg-card border-border">
        <CardHeader className="pb-2 pt-4 px-5">
          <CardTitle className="text-[10px] uppercase tracking-widest text-muted-foreground flex items-center gap-2">
            <Activity className="w-3 h-3" /> Execution History
          </CardTitle>
        </CardHeader>
        <CardContent className="px-0 pb-0">
          <Table>
            <TableHeader>
              <TableRow className="border-border bg-muted/30">
                <TableHead className="w-[80px] pl-5 text-[10px]">ID</TableHead>
                <TableHead className="text-[10px]">STATUS</TableHead>
                <TableHead className="text-[10px]">STARTED</TableHead>
                <TableHead className="text-[10px]">DURATION</TableHead>
                <TableHead className="text-[10px] pr-5">NODE</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoadingExecs ? (
                <TableRow>
                  <TableCell colSpan={5} className="h-24 text-center text-muted-foreground text-sm">
                    <Activity className="w-4 h-4 animate-pulse mx-auto mb-1" />Loading...
                  </TableCell>
                </TableRow>
              ) : !execs?.content || execs.content.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="h-24 text-center text-muted-foreground text-sm">No execution history</TableCell>
                </TableRow>
              ) : (
                execs.content.map(exec => (
                  <TableRow key={exec.id} className="hover:bg-muted/20 transition-colors border-border">
                    <TableCell className="font-mono text-xs text-muted-foreground pl-5">#{exec.id}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1.5 text-xs">
                        {exec.status === "SUCCESS" && <CheckCircle className="w-3 h-3 text-green-500" />}
                        {exec.status === "FAILED" && <XCircle className="w-3 h-3 text-destructive" />}
                        {exec.status === "RUNNING" && <Activity className="w-3 h-3 text-primary animate-pulse" />}
                        {exec.status === "SKIPPED" && <Clock className="w-3 h-3 text-muted-foreground" />}
                        <span className={
                          exec.status === "SUCCESS" ? "text-green-500" :
                          exec.status === "FAILED" ? "text-destructive" :
                          exec.status === "RUNNING" ? "text-primary" : "text-muted-foreground"
                        }>{exec.status}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-xs font-mono text-muted-foreground">{new Date(exec.startedAt).toLocaleString()}</TableCell>
                    <TableCell className="text-xs font-mono">{exec.durationMs ? `${exec.durationMs}ms` : "—"}</TableCell>
                    <TableCell className="text-xs font-mono text-muted-foreground pr-5">{exec.nodeName || exec.nodeId || "—"}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>

          {execs && execs.totalPages > 1 && (
            <div className="flex items-center justify-between px-5 py-3 border-t border-border">
              <span className="text-[10px] text-muted-foreground font-mono">PAGE {execs.page + 1} / {execs.totalPages}</span>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0} className="h-7 text-xs font-mono">PREV</Button>
                <Button variant="outline" size="sm" onClick={() => setPage(p => Math.min(execs.totalPages - 1, p + 1))} disabled={page >= execs.totalPages - 1} className="h-7 text-xs font-mono">NEXT</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
