import React from "react";
import {
  useGetStats, getGetStatsQueryKey,
  useGetLeader, getGetLeaderQueryKey
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, Server, CheckCircle, XCircle, Clock, Shield, TrendingUp, Zap } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  AreaChart, Area,
  BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell
} from "recharts";

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-card border border-border rounded px-3 py-2 text-xs font-mono shadow-lg">
        <p className="text-muted-foreground mb-1">{label}</p>
        {payload.map((p: any, i: number) => (
          <p key={i} style={{ color: p.color }}>{p.name}: <span className="text-foreground font-bold">{p.value}</span></p>
        ))}
      </div>
    );
  }
  return null;
};

function StatCard({
  label, value, sub, icon: Icon, colorClass, borderClass
}: {
  label: string; value: React.ReactNode; sub?: string;
  icon: React.ElementType; colorClass: string; borderClass: string;
}) {
  return (
    <Card className={`bg-card border-border overflow-hidden ${borderClass}`}>
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div className="space-y-1.5">
            <p className="text-[10px] font-medium text-muted-foreground uppercase tracking-widest">{label}</p>
            <div className={`text-3xl font-bold tabular-nums ${colorClass}`}>{value}</div>
            {sub && <p className="text-xs text-muted-foreground">{sub}</p>}
          </div>
          <div className={`p-2.5 rounded-md bg-current/10 ${colorClass}`}>
            <Icon className={`w-5 h-5 ${colorClass}`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Dashboard() {
  const { data: stats, isLoading } = useGetStats({
    query: { queryKey: getGetStatsQueryKey(), refetchInterval: 5000 }
  });
  const { data: leader } = useGetLeader({
    query: { queryKey: getGetLeaderQueryKey(), refetchInterval: 5000 }
  });

  if (isLoading || !stats) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="flex flex-col items-center gap-4 text-primary">
          <div className="relative">
            <Activity className="w-8 h-8 animate-pulse" />
            <div className="absolute inset-0 w-8 h-8 border border-primary/30 rounded-full animate-ping" />
          </div>
          <span className="tracking-widest text-sm text-muted-foreground">LOADING TELEMETRY...</span>
        </div>
      </div>
    );
  }

  const successRate = stats.totalExecutions > 0
    ? Math.round((stats.successfulExecutions / stats.totalExecutions) * 100) : 0;

  const byDayData = (stats.executionsByDay ?? []).map((d: any) => ({
    day: d.day?.substring(5) ?? d.day,
    count: Number(d.count)
  }));

  const statusDonutData = (stats.jobsByStatus ?? []).map((s: any) => ({
    name: s.status,
    value: Number(s.count),
    color: s.status === "ACTIVE" ? "#22c55e" : s.status === "PAUSED" ? "#eab308" : "#ef4444"
  }));

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Active Jobs" value={stats.activeJobs}
          sub={`of ${stats.totalJobs} total`}
          icon={Zap} colorClass="text-primary" borderClass="stat-card-primary"
        />
        <StatCard
          label="Active Nodes" value={stats.activeNodes}
          sub={`of ${stats.totalNodes} registered`}
          icon={Server} colorClass="text-sky-400" borderClass="stat-card-primary"
        />
        <StatCard
          label="Success Rate" value={`${successRate}%`}
          sub={`${stats.successfulExecutions} successful`}
          icon={CheckCircle} colorClass="text-green-500" borderClass="stat-card-green"
        />
        <StatCard
          label="Failed Runs" value={stats.failedExecutions}
          sub="total failures"
          icon={XCircle} colorClass="text-destructive" borderClass="stat-card-red"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-[10px] uppercase tracking-widest text-muted-foreground flex items-center gap-2">
              <Shield className="w-3.5 h-3.5 text-primary" />
              Cluster Leadership
            </CardTitle>
          </CardHeader>
          <CardContent>
            {leader ? (
              <div className="space-y-4">
                <div className="relative flex items-center gap-3 p-4 border border-primary/25 bg-primary/5 rounded-md overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-transparent pointer-events-none" />
                  <div className="relative">
                    <div className="w-3 h-3 rounded-full bg-primary" />
                    <div className="absolute inset-0 w-3 h-3 rounded-full bg-primary/40 ping-slow" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-sm text-primary truncate">{leader.hostname}</p>
                    <p className="text-[10px] text-muted-foreground">Current Leader</p>
                  </div>
                  <Badge variant="outline" className="bg-primary/15 text-primary border-primary/30 text-[9px] tracking-wider shrink-0">
                    ● LEADER
                  </Badge>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
                  <div className="bg-muted/30 rounded p-2 border border-border/50">
                    <div className="text-muted-foreground mb-0.5">NODE_ID</div>
                    <div className="text-foreground truncate">{leader.nodeId.substring(0, 12)}…</div>
                  </div>
                  <div className="bg-muted/30 rounded p-2 border border-border/50">
                    <div className="text-muted-foreground mb-0.5">IP_ADDR</div>
                    <div className="text-foreground">{leader.ipAddress || "N/A"}</div>
                  </div>
                  <div className="bg-muted/30 rounded p-2 border border-border/50 col-span-2">
                    <div className="text-muted-foreground mb-0.5">HEARTBEAT</div>
                    <div className="text-green-500">{new Date(leader.lastHeartbeatAt).toLocaleTimeString()}</div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-4 border border-destructive/25 bg-destructive/5 text-destructive rounded-md flex items-center gap-2 text-sm">
                <XCircle className="w-4 h-4 shrink-0" />
                <span>NO LEADER — CLUSTER UNHEALTHY</span>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-[10px] uppercase tracking-widest text-muted-foreground flex items-center gap-2">
              <TrendingUp className="w-3.5 h-3.5 text-primary" />
              Executions by Day
            </CardTitle>
          </CardHeader>
          <CardContent>
            {byDayData.length > 0 ? (
              <ResponsiveContainer width="100%" height={160}>
                <AreaChart data={byDayData} margin={{ top: 4, right: 4, left: -32, bottom: 0 }}>
                  <defs>
                    <linearGradient id="execGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(199 89% 52%)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="hsl(199 89% 52%)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="2 4" stroke="hsl(220 15% 13%)" vertical={false} />
                  <XAxis dataKey="day" tick={{ fontSize: 9, fontFamily: "JetBrains Mono, monospace", fill: "hsl(220 10% 55%)" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 9, fontFamily: "JetBrains Mono, monospace", fill: "hsl(220 10% 55%)" }} axisLine={false} tickLine={false} allowDecimals={false} />
                  <Tooltip content={<CustomTooltip />} />
                  <Area type="monotone" dataKey="count" name="Executions" stroke="hsl(199 89% 52%)" strokeWidth={2} fill="url(#execGrad)" dot={false} activeDot={{ r: 3, fill: "hsl(199 89% 52%)" }} />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-40 flex items-center justify-center text-muted-foreground text-xs">NO DATA YET</div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-[10px] uppercase tracking-widest text-muted-foreground flex items-center gap-2">
              <Activity className="w-3.5 h-3.5 text-primary" />
              Jobs by Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            {statusDonutData.length > 0 ? (
              <>
                <ResponsiveContainer width="100%" height={120}>
                  <BarChart data={statusDonutData} margin={{ top: 4, right: 4, left: -32, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="2 4" stroke="hsl(220 15% 13%)" vertical={false} />
                    <XAxis dataKey="name" tick={{ fontSize: 9, fontFamily: "JetBrains Mono, monospace", fill: "hsl(220 10% 55%)" }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 9, fontFamily: "JetBrains Mono, monospace", fill: "hsl(220 10% 55%)" }} axisLine={false} tickLine={false} allowDecimals={false} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="value" name="Jobs" radius={[3, 3, 0, 0]}>
                      {statusDonutData.map((entry: any, i: number) => (
                        <Cell key={i} fill={entry.color} fillOpacity={0.85} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
                <div className="flex gap-3 mt-2">
                  {statusDonutData.map((s: any) => (
                    <div key={s.name} className="flex items-center gap-1.5 text-[10px]">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: s.color }} />
                      <span className="text-muted-foreground">{s.name}</span>
                      <span className="text-foreground font-bold">{s.value}</span>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="h-40 flex items-center justify-center text-muted-foreground text-xs">NO DATA YET</div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-[10px] uppercase tracking-widest text-muted-foreground flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-primary" />
            Recent Executions
          </CardTitle>
        </CardHeader>
        <CardContent>
          {stats.recentExecutions && stats.recentExecutions.length > 0 ? (
            <div className="space-y-1">
              {stats.recentExecutions.map((exec: any) => (
                <div
                  key={exec.id}
                  className="flex items-center gap-3 px-3 py-2 rounded hover:bg-muted/30 transition-colors text-sm border border-transparent hover:border-border/50"
                >
                  <div className="shrink-0">
                    {exec.status === "SUCCESS" && <CheckCircle className="w-4 h-4 text-green-500" />}
                    {exec.status === "FAILED" && <XCircle className="w-4 h-4 text-destructive" />}
                    {exec.status === "RUNNING" && <Activity className="w-4 h-4 text-primary animate-pulse" />}
                    {exec.status === "SKIPPED" && <Clock className="w-4 h-4 text-muted-foreground" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="font-medium truncate block">{exec.jobName || `Job #${exec.jobId}`}</span>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    {exec.durationMs && (
                      <span className="text-[10px] text-muted-foreground tabular-nums">{exec.durationMs}ms</span>
                    )}
                    <span className="text-[10px] text-muted-foreground tabular-nums">
                      {new Date(exec.startedAt).toLocaleTimeString()}
                    </span>
                    <Badge
                      variant="outline"
                      className={`text-[9px] h-4 px-1.5 ${
                        exec.status === "SUCCESS" ? "border-green-500/40 text-green-500 bg-green-500/10" :
                        exec.status === "FAILED" ? "border-destructive/40 text-destructive bg-destructive/10" :
                        exec.status === "RUNNING" ? "border-primary/40 text-primary bg-primary/10" :
                        "border-border text-muted-foreground"
                      }`}
                    >
                      {exec.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-8 text-center text-sm text-muted-foreground border border-dashed border-border rounded">
              No recent executions
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
