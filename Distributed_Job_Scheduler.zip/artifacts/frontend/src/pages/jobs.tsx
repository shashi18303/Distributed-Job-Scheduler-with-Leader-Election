import React, { useState } from "react";
import { Link } from "wouter";
import { useListJobs, getListJobsQueryKey, useDeleteJob, usePauseJob, useResumeJob, useTriggerJob } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Activity, Play, Pause, Trash2, Plus, TerminalSquare, AlertCircle, RefreshCw } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Jobs() {
  const [page, setPage] = useState(0);
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const queryClient = useQueryClient();
  
  const queryParams = {
    page,
    size: 20,
    ...(statusFilter !== "ALL" ? { status: statusFilter } : {})
  };

  const { data: jobPage, isLoading } = useListJobs(queryParams, {
    query: {
      queryKey: getListJobsQueryKey(queryParams),
      refetchInterval: 5000,
    }
  });

  const deleteJob = useDeleteJob({
    mutation: {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getListJobsQueryKey(queryParams) })
    }
  });

  const pauseJob = usePauseJob({
    mutation: {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getListJobsQueryKey(queryParams) })
    }
  });

  const resumeJob = useResumeJob({
    mutation: {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getListJobsQueryKey(queryParams) })
    }
  });

  const triggerJob = useTriggerJob({
    mutation: {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getListJobsQueryKey(queryParams) })
    }
  });

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this job?")) {
      deleteJob.mutate({ id });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h2 className="text-lg font-bold tracking-widest text-primary flex items-center gap-2">
            <TerminalSquare className="w-5 h-5" />
            JOBS_REGISTRY
          </h2>
          
          <Select value={statusFilter} onValueChange={(val) => { setStatusFilter(val); setPage(0); }}>
            <SelectTrigger className="w-[180px] bg-background font-mono h-8 border-border">
              <SelectValue placeholder="Filter Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">ALL_STATUSES</SelectItem>
              <SelectItem value="ACTIVE">ACTIVE</SelectItem>
              <SelectItem value="PAUSED">PAUSED</SelectItem>
              <SelectItem value="DISABLED">DISABLED</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <Link href="/jobs/new" className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground shadow hover:bg-primary/90 h-9 px-4 py-2 tracking-widest gap-2">
          <Plus className="w-4 h-4" />
          NEW_JOB
        </Link>
      </div>

      <div className="border border-border rounded-md bg-card overflow-hidden">
        <Table>
          <TableHeader className="bg-muted/50">
            <TableRow>
              <TableHead className="w-[80px]">ID</TableHead>
              <TableHead>NAME</TableHead>
              <TableHead>CRON</TableHead>
              <TableHead>TYPE</TableHead>
              <TableHead>STATUS</TableHead>
              <TableHead>NEXT_RUN</TableHead>
              <TableHead className="text-right">ACTIONS</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={7} className="h-32 text-center text-muted-foreground">
                  <div className="flex flex-col items-center justify-center gap-2">
                    <Activity className="w-5 h-5 animate-pulse text-primary" />
                    <span>FETCHING_RECORDS...</span>
                  </div>
                </TableCell>
              </TableRow>
            ) : !jobPage?.content || jobPage.content.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="h-32 text-center text-muted-foreground">
                  <div className="flex flex-col items-center justify-center gap-2">
                    <AlertCircle className="w-5 h-5" />
                    <span>NO_JOBS_FOUND</span>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              jobPage.content.map((job) => (
                <TableRow key={job.id} className="hover:bg-muted/30 transition-colors">
                  <TableCell className="font-mono text-muted-foreground">#{job.id}</TableCell>
                  <TableCell>
                    <Link href={`/jobs/${job.id}`} className="font-bold text-primary hover:underline underline-offset-4 decoration-primary/50">
                      {job.name}
                    </Link>
                    {job.description && (
                      <p className="text-xs text-muted-foreground truncate max-w-xs">{job.description}</p>
                    )}
                  </TableCell>
                  <TableCell className="font-mono text-xs">{job.cronExpression}</TableCell>
                  <TableCell className="text-xs">{job.jobType}</TableCell>
                  <TableCell>
                    <Badge 
                      variant="outline" 
                      className={
                        job.status === "ACTIVE" ? "border-green-500/50 text-green-500 bg-green-500/10" :
                        job.status === "PAUSED" ? "border-yellow-500/50 text-yellow-500 bg-yellow-500/10" :
                        "border-red-500/50 text-red-500 bg-red-500/10"
                      }
                    >
                      {job.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {job.nextExecutionAt ? new Date(job.nextExecutionAt).toLocaleString() : 'N/A'}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-blue-500 hover:text-blue-400 hover:bg-blue-500/10"
                        title="Trigger Now"
                        onClick={() => triggerJob.mutate({ id: job.id })}
                        disabled={triggerJob.isPending}
                      >
                        <Play className="w-4 h-4" />
                      </Button>
                      
                      {job.status === 'ACTIVE' ? (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-yellow-500 hover:text-yellow-400 hover:bg-yellow-500/10"
                          title="Pause Job"
                          onClick={() => pauseJob.mutate({ id: job.id })}
                          disabled={pauseJob.isPending}
                        >
                          <Pause className="w-4 h-4" />
                        </Button>
                      ) : job.status === 'PAUSED' ? (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-green-500 hover:text-green-400 hover:bg-green-500/10"
                          title="Resume Job"
                          onClick={() => resumeJob.mutate({ id: job.id })}
                          disabled={resumeJob.isPending}
                        >
                          <RefreshCw className="w-4 h-4" />
                        </Button>
                      ) : (
                        <div className="h-8 w-8" />
                      )}

                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                        title="Delete Job"
                        onClick={() => handleDelete(job.id)}
                        disabled={deleteJob.isPending}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
        
        {jobPage && jobPage.totalPages > 1 && (
          <div className="flex items-center justify-between p-4 border-t border-border bg-muted/20">
            <span className="text-xs text-muted-foreground">
              PAGE {jobPage.page + 1} OF {jobPage.totalPages}
            </span>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage(p => Math.max(0, p - 1))}
                disabled={page === 0}
                className="h-8 text-xs font-mono"
              >
                PREV
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage(p => Math.min(jobPage.totalPages - 1, p + 1))}
                disabled={page >= jobPage.totalPages - 1}
                className="h-8 text-xs font-mono"
              >
                NEXT
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
