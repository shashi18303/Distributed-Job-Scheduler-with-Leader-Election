import React, { useState } from "react";
import { useLocation } from "wouter";
import { useCreateJob } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TerminalSquare, ArrowLeft, Clock, Info } from "lucide-react";
import { Link } from "wouter";

const createJobSchema = z.object({
  name: z.string().min(1, "Name required").max(100),
  description: z.string().optional(),
  cronExpression: z.string().min(1, "Cron expression required"),
  jobType: z.enum(["HTTP_REQUEST", "SHELL_COMMAND", "DATA_CLEANUP", "EMAIL_NOTIFICATION", "REPORT_GENERATION", "CUSTOM"]),
  payload: z.string().optional()
});

const CRON_PRESETS = [
  { label: "Every minute", value: "0 * * * * *" },
  { label: "Every 5 minutes", value: "0 */5 * * * *" },
  { label: "Every 30 minutes", value: "0 */30 * * * *" },
  { label: "Hourly", value: "0 0 * * * *" },
  { label: "Daily at midnight", value: "0 0 0 * * *" },
  { label: "Weekly (Mon 9am)", value: "0 0 9 * * MON" },
];

const JOB_TYPES = [
  { value: "HTTP_REQUEST", desc: "Perform an HTTP call to an external endpoint" },
  { value: "SHELL_COMMAND", desc: "Execute a shell command on the leader node" },
  { value: "DATA_CLEANUP", desc: "Run database or storage cleanup routines" },
  { value: "EMAIL_NOTIFICATION", desc: "Send scheduled email alerts" },
  { value: "REPORT_GENERATION", desc: "Generate and store periodic reports" },
  { value: "CUSTOM", desc: "Custom job with arbitrary payload" },
];

export default function NewJob() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [showPresets, setShowPresets] = useState(false);

  const form = useForm<z.infer<typeof createJobSchema>>({
    resolver: zodResolver(createJobSchema),
    defaultValues: {
      name: "",
      description: "",
      cronExpression: "0 0 * * * *",
      jobType: "HTTP_REQUEST",
      payload: ""
    }
  });

  const createJob = useCreateJob({
    mutation: {
      onSuccess: (data) => {
        toast({ title: "JOB_CREATED", description: `Job #${data.id} initialized successfully.` });
        setLocation("/jobs");
      },
      onError: () => {
        toast({ title: "INITIALIZATION_FAILED", description: "Failed to create job.", variant: "destructive" });
      }
    }
  });

  const onSubmit = (data: z.infer<typeof createJobSchema>) => {
    createJob.mutate({ data });
  };

  const selectedType = JOB_TYPES.find(t => t.value === form.watch("jobType"));

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <Link href="/jobs" className="p-1.5 text-muted-foreground hover:text-primary hover:bg-primary/10 rounded transition-colors">
          <ArrowLeft className="w-4 h-4" />
        </Link>
        <div>
          <h2 className="text-base font-bold tracking-widest text-primary flex items-center gap-2">
            <TerminalSquare className="w-4 h-4" />
            NEW_JOB_DEFINITION
          </h2>
          <p className="text-[10px] text-muted-foreground mt-0.5">Define a new scheduled job for the cluster</p>
        </div>
      </div>

      <div className="border border-border rounded-md bg-card overflow-hidden">
        <div className="px-5 py-3 border-b border-border bg-muted/20 flex items-center gap-2 text-[10px] text-muted-foreground">
          <div className="w-2 h-2 rounded-full bg-yellow-500/70" />
          <div className="w-2 h-2 rounded-full bg-green-500/70" />
          <div className="w-2 h-2 rounded-full bg-primary/70" />
          <span className="ml-2 tracking-wider">job.config</span>
        </div>

        <div className="p-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-[10px] uppercase tracking-[0.15em] text-muted-foreground">
                        <span className="text-primary mr-1">//</span> Job Name
                      </FormLabel>
                      <FormControl>
                        <Input
                          placeholder="sync-users-daily"
                          {...field}
                          className="font-mono bg-background border-border focus:border-primary/50 text-sm"
                        />
                      </FormControl>
                      <FormMessage className="text-xs" />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="jobType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-[10px] uppercase tracking-[0.15em] text-muted-foreground">
                        <span className="text-primary mr-1">//</span> Execution Type
                      </FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-background font-mono text-sm border-border">
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {JOB_TYPES.map(t => (
                            <SelectItem key={t.value} value={t.value} className="font-mono text-xs">
                              {t.value}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {selectedType && (
                        <p className="text-[10px] text-muted-foreground flex items-center gap-1">
                          <Info className="w-2.5 h-2.5" />{selectedType.desc}
                        </p>
                      )}
                      <FormMessage className="text-xs" />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-[10px] uppercase tracking-[0.15em] text-muted-foreground">
                      <span className="text-primary mr-1">//</span> Description
                    </FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Brief description of what this job does"
                        {...field}
                        className="bg-background border-border focus:border-primary/50 text-sm"
                      />
                    </FormControl>
                    <FormMessage className="text-xs" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="cronExpression"
                render={({ field }) => (
                  <FormItem>
                    <div className="flex items-center justify-between">
                      <FormLabel className="text-[10px] uppercase tracking-[0.15em] text-muted-foreground">
                        <span className="text-primary mr-1">//</span> Cron Schedule
                      </FormLabel>
                      <button
                        type="button"
                        onClick={() => setShowPresets(p => !p)}
                        className="text-[10px] text-primary hover:underline flex items-center gap-1"
                      >
                        <Clock className="w-2.5 h-2.5" />
                        {showPresets ? "Hide" : "Show"} presets
                      </button>
                    </div>
                    {showPresets && (
                      <div className="grid grid-cols-2 gap-1.5 mb-2">
                        {CRON_PRESETS.map(p => (
                          <button
                            key={p.value}
                            type="button"
                            onClick={() => { field.onChange(p.value); setShowPresets(false); }}
                            className="text-left px-2.5 py-1.5 text-[10px] border border-border hover:border-primary/40 hover:bg-primary/5 rounded transition-colors font-mono"
                          >
                            <div className="text-muted-foreground">{p.label}</div>
                            <div className="text-primary/80">{p.value}</div>
                          </button>
                        ))}
                      </div>
                    )}
                    <FormControl>
                      <Input
                        placeholder="0 0 * * * *"
                        {...field}
                        className="font-mono bg-background border-border focus:border-primary/50 text-sm"
                      />
                    </FormControl>
                    <FormDescription className="text-[10px] text-muted-foreground">
                      Spring cron: <span className="text-primary/70 font-mono">sec min hour day month day-of-week</span>
                    </FormDescription>
                    <FormMessage className="text-xs" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="payload"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-[10px] uppercase tracking-[0.15em] text-muted-foreground">
                      <span className="text-primary mr-1">//</span> Payload / Config (JSON)
                    </FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder={`{\n  "endpoint": "https://api.example.com/sync",\n  "method": "POST"\n}`}
                        {...field}
                        className="font-mono bg-background border-border focus:border-primary/50 min-h-[120px] text-sm resize-none"
                      />
                    </FormControl>
                    <FormDescription className="text-[10px] text-muted-foreground">
                      Required for HTTP_REQUEST and CUSTOM job types.
                    </FormDescription>
                    <FormMessage className="text-xs" />
                  </FormItem>
                )}
              />

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-border">
                <Link
                  href="/jobs"
                  className="inline-flex items-center justify-center h-9 px-4 text-sm font-mono tracking-wider border border-input bg-background hover:bg-accent hover:text-accent-foreground rounded-md transition-colors"
                >
                  CANCEL
                </Link>
                <Button
                  type="submit"
                  disabled={createJob.isPending}
                  className="tracking-widest font-mono shadow-[0_0_15px_rgba(14,165,233,0.2)] hover:shadow-[0_0_25px_rgba(14,165,233,0.4)] transition-all"
                >
                  {createJob.isPending ? (
                    <span className="flex items-center gap-2">
                      <span className="w-3 h-3 border border-primary-foreground/50 border-t-primary-foreground rounded-full animate-spin" />
                      INITIALIZING...
                    </span>
                  ) : "CREATE_JOB"}
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
}
