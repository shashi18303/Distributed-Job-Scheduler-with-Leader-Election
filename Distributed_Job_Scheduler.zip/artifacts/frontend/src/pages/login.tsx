import React, { useEffect, useState } from "react";
import { useLogin } from "@workspace/api-client-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

const loginSchema = z.object({
  username: z.string().min(1, "Username required"),
  password: z.string().min(1, "Password required")
});

const BOOT_LINES = [
  "Initializing distributed scheduler kernel...",
  "Loading leader election module [OK]",
  "Starting heartbeat service [OK]",
  "Connecting to PostgreSQL cluster [OK]",
  "Mounting job registry [OK]",
  "Starting fault tolerance watchdog [OK]",
  "All systems operational.",
  "",
  "SCHEDULER_OS v2.1.0  |  Java 21 + Spring Boot 3",
];

export default function Login() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [bootLines, setBootLines] = useState<string[]>([]);
  const [bootDone, setBootDone] = useState(false);
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    let i = 0;
    const interval = setInterval(() => {
      if (i < BOOT_LINES.length) {
        setBootLines(prev => [...prev, BOOT_LINES[i]]);
        i++;
      } else {
        clearInterval(interval);
        setTimeout(() => setBootDone(true), 300);
      }
    }, 120);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const form = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: { username: "admin", password: "" }
  });

  const loginMutation = useLogin({
    mutation: {
      onSuccess: () => { setLocation("/dashboard"); },
      onError: () => {
        toast({ title: "AUTH_FAILED", description: "Invalid credentials. Access denied.", variant: "destructive" });
      }
    }
  });

  const onSubmit = (data: z.infer<typeof loginSchema>) => {
    loginMutation.mutate({ data });
  };

  return (
    <div className="min-h-screen bg-background grid-bg flex flex-col items-center justify-center p-4 font-mono dark scanlines">
      <div className="w-full max-w-lg space-y-6">

        <div className="text-center space-y-1">
          <div className="flex items-center justify-center gap-3 mb-2">
            <div className="w-px h-8 bg-primary/50" />
            <h1 className="text-3xl font-bold tracking-[0.25em] text-primary">SCHEDULER_OS</h1>
            <div className="w-px h-8 bg-primary/50" />
          </div>
          <p className="text-[10px] tracking-[0.4em] text-muted-foreground uppercase">Distributed Cluster Control Terminal</p>
          <p className="text-[10px] text-muted-foreground/60 tabular-nums">{time.toISOString()}</p>
        </div>

        <div className="bg-black/60 border border-border rounded-md p-4 h-52 overflow-hidden font-mono text-[11px] leading-5">
          {bootLines.map((line, i) => {
            const isEmpty = !line || line.trim() === "";
            const isHeader = !isEmpty && line.startsWith("SCHEDULER");
            const isOk = !isEmpty && line.includes("[OK]");
            return (
              <div
                key={i}
                className={isEmpty ? "h-3" : isHeader ? "text-primary font-bold mt-1" : isOk ? "text-green-400" : "text-muted-foreground"}
              >
                {!isEmpty && !isHeader && (
                  <span className="text-primary/50 mr-2">$</span>
                )}
                {line}
                {i === bootLines.length - 1 && !bootDone && (
                  <span className="animate-pulse text-primary ml-1">▋</span>
                )}
              </div>
            );
          })}
        </div>

        <div
          className={`bg-card border border-border rounded-md p-8 shadow-2xl transition-all duration-500 ${
            bootDone ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4 pointer-events-none"
          }`}
        >
          <div className="mb-6 flex items-center gap-2 text-xs text-muted-foreground border-b border-border pb-4">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span>SECURE ACCESS TERMINAL — AUTHENTICATION REQUIRED</span>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                      <span className="text-primary mr-1">//</span> USERNAME
                    </FormLabel>
                    <FormControl>
                      <Input
                        placeholder="admin"
                        {...field}
                        className="font-mono bg-background border-border focus:border-primary/50 focus:ring-0 focus:shadow-[0_0_0_1px_hsl(var(--primary)/0.3)] transition-all"
                      />
                    </FormControl>
                    <FormMessage className="text-xs" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                      <span className="text-primary mr-1">//</span> PASSWORD
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="password"
                        placeholder="••••••••"
                        autoComplete="current-password"
                        {...field}
                        className="font-mono bg-background border-border focus:border-primary/50 focus:ring-0 focus:shadow-[0_0_0_1px_hsl(var(--primary)/0.3)] transition-all"
                      />
                    </FormControl>
                    <FormMessage className="text-xs" />
                  </FormItem>
                )}
              />

              <Button
                type="submit"
                className="w-full font-bold tracking-[0.2em] uppercase bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_20px_rgba(14,165,233,0.25)] hover:shadow-[0_0_30px_rgba(14,165,233,0.45)] transition-all duration-200"
                disabled={loginMutation.isPending}
              >
                {loginMutation.isPending ? (
                  <span className="flex items-center gap-2">
                    <span className="w-3 h-3 border border-primary-foreground/50 border-t-primary-foreground rounded-full animate-spin" />
                    AUTHENTICATING...
                  </span>
                ) : "INITIALIZE SESSION"}
              </Button>
            </form>
          </Form>
        </div>

        <p className="text-center text-[10px] text-muted-foreground/40 tracking-widest">
          JAVA 21 · SPRING BOOT 3 · POSTGRESQL · DOCKER
        </p>
      </div>
    </div>
  );
}
