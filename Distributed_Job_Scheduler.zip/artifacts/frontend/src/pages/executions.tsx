import React, { useState } from "react";
import { Link } from "wouter";
import { useListExecutions, getListExecutionsQueryKey, useGetExecution, getGetExecutionQueryKey } from "@workspace/api-client-react";
import { Activity, Clock, CheckCircle, XCircle, TerminalSquare, Info } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";

function ExecutionDetailDialog({ id, open, onOpenChange }: { id: number | null, open: boolean, onOpenChange: (open: boolean) => void }) {
  const { data: exec, isLoading } = useGetExecution(id || 0, {
    query: {
      queryKey: getGetExecutionQueryKey(id || 0),
      enabled: !!id && open
    }
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl bg-card border-border">
        <DialogHeader>
          <DialogTitle className="text-lg tracking-widest text-primary flex items-center gap-2 font-mono">
            <Info className="w-5 h-5" />
            EXECUTION_DETAILS #{id}
          </DialogTitle>
          <DialogDescription className="font-mono text-xs">Full run log and metadata</DialogDescription>
        </DialogHeader>
        {isLoading ? (
          <div className="py-12 flex justify-center"><Activity className="w-6 h-6 animate-pulse text-primary" /></div>
        ) : exec ? (
          <div className="space-y-4 font-mono text-sm">
            <div className="grid grid-cols-2 gap-4 bg-muted/20 p-4 rounded-md border border-border/50">
              <div>
                <p className="text-xs text-muted-foreground mb-1">JOB</p>
                <p>{exec.jobName || `Job #${exec.jobId}`}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">STATUS</p>
                <p className={
                  exec.status === 'SUCCESS' ? 'text-green-500' :
                  exec.status === 'FAILED' ? 'text-destructive' :
                  exec.status === 'RUNNING' ? 'text-blue-500' : 'text-muted-foreground'
                }>{exec.status}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">TIMING</p>
                <p>{new Date(exec.startedAt).toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Duration: {exec.durationMs ? `${exec.durationMs}ms` : '-'}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">NODE</p>
                <p>{exec.nodeName || exec.nodeId || 'UNKNOWN'}</p>
              </div>
            </div>
            
            {exec.errorMessage && (
              <div>
                <p className="text-xs text-muted-foreground mb-1 text-destructive">ERROR_MESSAGE</p>
                <pre className="bg-destructive/10 text-destructive border border-destructive/30 p-3 rounded text-xs whitespace-pre-wrap">
                  {exec.errorMessage}
                </pre>
              </div>
            )}

            {exec.output && (
              <div>
                <p className="text-xs text-muted-foreground mb-1">STDOUT/OUTPUT</p>
                <pre className="bg-black/50 text-green-400 border border-border/50 p-3 rounded text-xs overflow-x-auto max-h-[300px] overflow-y-auto">
                  {exec.output}
                </pre>
              </div>
            )}
          </div>
        ) : (
          <div className="py-12 text-center text-muted-foreground">No data found</div>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default function Executions() {
  const [page, setPage] = useState(0);
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [jobIdFilter, setJobIdFilter] = useState<string>("");
  const [selectedExecId, setSelectedExecId] = useState<number | null>(null);

  const queryParams = {
    page,
    size: 20,
    ...(statusFilter !== "ALL" ? { status: statusFilter } : {}),
    ...(jobIdFilter && !isNaN(parseInt(jobIdFilter, 10)) ? { jobId: parseInt(jobIdFilter, 10) } : {})
  };

  const { data: execs, isLoading } = useListExecutions(queryParams, {
    query: {
      queryKey: getListExecutionsQueryKey(queryParams),
      refetchInterval: 5000,
    }
  });

  const handleJobIdSearch = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      setPage(0);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h2 className="text-lg font-bold tracking-widest text-primary flex items-center gap-2">
          <Activity className="w-5 h-5" />
          EXECUTION_LOGS
        </h2>
        
        <div className="flex items-center gap-2">
          <Input 
            placeholder="Filter by Job ID..." 
            value={jobIdFilter}
            onChange={(e) => setJobIdFilter(e.target.value)}
            onKeyDown={handleJobIdSearch}
            className="w-[150px] h-8 font-mono text-xs bg-background border-border"
          />
          <Select value={statusFilter} onValueChange={(val) => { setStatusFilter(val); setPage(0); }}>
            <SelectTrigger className="w-[150px] bg-background font-mono text-xs h-8 border-border">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">ALL</SelectItem>
              <SelectItem value="RUNNING">RUNNING</SelectItem>
              <SelectItem value="SUCCESS">SUCCESS</SelectItem>
              <SelectItem value="FAILED">FAILED</SelectItem>
              <SelectItem value="SKIPPED">SKIPPED</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="border border-border rounded-md bg-card overflow-hidden">
        <Table>
          <TableHeader className="bg-muted/50">
            <TableRow>
              <TableHead className="w-[80px]">ID</TableHead>
              <TableHead>JOB</TableHead>
              <TableHead>STATUS</TableHead>
              <TableHead>STARTED</TableHead>
              <TableHead>DURATION</TableHead>
              <TableHead>NODE</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={6} className="h-32 text-center text-muted-foreground">
                  <div className="flex flex-col items-center justify-center gap-2">
                    <Activity className="w-5 h-5 animate-pulse text-primary" />
                    <span>FETCHING_LOGS...</span>
                  </div>
                </TableCell>
              </TableRow>
            ) : !execs?.content || execs.content.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="h-32 text-center text-muted-foreground">
                  NO_EXECUTIONS_FOUND
                </TableCell>
              </TableRow>
            ) : (
              execs.content.map((exec) => (
                <TableRow key={exec.id} className="hover:bg-muted/30 transition-colors">
                  <TableCell className="font-mono text-muted-foreground text-xs">#{exec.id}</TableCell>
                  <TableCell>
                    <Link href={`/jobs/${exec.jobId}`} className="flex items-center gap-2 text-primary hover:underline underline-offset-4 decoration-primary/50 text-sm font-medium">
                      <TerminalSquare className="w-3 h-3" />
                      {exec.jobName || `Job #${exec.jobId}`}
                    </Link>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2 text-xs font-mono">
                      {exec.status === 'SUCCESS' && <CheckCircle className="w-3 h-3 text-green-500" />}
                      {exec.status === 'FAILED' && <XCircle className="w-3 h-3 text-destructive" />}
                      {exec.status === 'RUNNING' && <Activity className="w-3 h-3 text-blue-500 animate-pulse" />}
                      {exec.status === 'SKIPPED' && <Clock className="w-3 h-3 text-muted-foreground" />}
                      <span className={
                        exec.status === 'SUCCESS' ? 'text-green-500' :
                        exec.status === 'FAILED' ? 'text-destructive' :
                        exec.status === 'RUNNING' ? 'text-blue-500' : 'text-muted-foreground'
                      }>{exec.status}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-xs font-mono">{new Date(exec.startedAt).toLocaleString()}</TableCell>
                  <TableCell className="text-xs font-mono">{exec.durationMs ? `${exec.durationMs}ms` : '-'}</TableCell>
                  <TableCell className="text-xs font-mono text-muted-foreground">{exec.nodeName || exec.nodeId || '-'}</TableCell>
                  <TableCell>
                    <Button variant="ghost" size="sm" onClick={() => setSelectedExecId(exec.id)} className="h-6 w-6 p-0 hover:bg-primary/20 hover:text-primary">
                      <Info className="w-3 h-3" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>

        {execs && execs.totalPages > 1 && (
          <div className="flex items-center justify-between p-4 border-t border-border bg-muted/20">
            <span className="text-xs text-muted-foreground font-mono">
              PAGE {execs.page + 1} / {execs.totalPages}
            </span>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0} className="h-8 text-xs font-mono">PREV</Button>
              <Button variant="outline" size="sm" onClick={() => setPage(p => Math.min(execs.totalPages - 1, p + 1))} disabled={page >= execs.totalPages - 1} className="h-8 text-xs font-mono">NEXT</Button>
            </div>
          </div>
        )}
      </div>

      <ExecutionDetailDialog 
        id={selectedExecId} 
        open={selectedExecId !== null} 
        onOpenChange={(open) => !open && setSelectedExecId(null)} 
      />
    </div>
  );
}
