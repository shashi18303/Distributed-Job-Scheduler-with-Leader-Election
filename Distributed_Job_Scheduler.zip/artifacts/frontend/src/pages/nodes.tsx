import React from "react";
import { useListNodes, getListNodesQueryKey } from "@workspace/api-client-react";
import { Server, Activity, AlertCircle, Shield, Wifi, Clock } from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

function HeartbeatAge({ ts }: { ts: string }) {
  const diff = Math.floor((Date.now() - new Date(ts).getTime()) / 1000);
  const ok = diff < 15;
  const warn = diff < 30;
  return (
    <div className={`flex items-center gap-1.5 text-[10px] tabular-nums ${ok ? "text-green-500" : warn ? "text-yellow-500" : "text-destructive"}`}>
      <Wifi className="w-3 h-3" />
      <span>{diff < 60 ? `${diff}s ago` : `${Math.floor(diff / 60)}m ago`}</span>
    </div>
  );
}

export default function Nodes() {
  const { data: nodes, isLoading } = useListNodes({
    query: { queryKey: getListNodesQueryKey(), refetchInterval: 5000 }
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="flex flex-col items-center gap-4 text-primary">
          <div className="relative">
            <Server className="w-8 h-8 animate-pulse" />
            <div className="absolute inset-0 border border-primary/30 rounded animate-ping" />
          </div>
          <span className="tracking-widest text-sm text-muted-foreground">SCANNING CLUSTER TOPOLOGY...</span>
        </div>
      </div>
    );
  }

  if (!nodes || nodes.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 border border-dashed border-border rounded-lg bg-card/50">
        <AlertCircle className="w-8 h-8 text-muted-foreground mb-4" />
        <span className="text-muted-foreground text-sm">NO_NODES_REGISTERED</span>
      </div>
    );
  }

  const activeCount = nodes.filter((n: any) => n.status === "ACTIVE").length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Server className="w-5 h-5 text-primary" />
          <h2 className="text-lg font-bold tracking-widest text-primary">CLUSTER_TOPOLOGY</h2>
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground border border-border rounded px-3 py-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
          <span>{activeCount} / {nodes.length} nodes online</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {nodes.map((node: any) => {
          const isActive = node.status === "ACTIVE";
          const heartbeatDiff = Math.floor((Date.now() - new Date(node.lastHeartbeatAt).getTime()) / 1000);
          const heartbeatOk = heartbeatDiff < 15;

          return (
            <Card
              key={node.id}
              className={`border overflow-hidden transition-all duration-300 ${
                node.isLeader
                  ? "border-primary/40 shadow-[0_0_20px_rgba(14,165,233,0.12)]"
                  : isActive
                    ? "border-border hover:border-green-500/30"
                    : "border-destructive/30 opacity-75"
              } bg-card`}
            >
              <div className={`h-0.5 w-full ${
                node.isLeader ? "bg-gradient-to-r from-primary via-sky-400 to-primary" :
                isActive ? "bg-green-500/60" : "bg-destructive/60"
              }`} />

              <CardHeader className="pb-0 pt-4 px-4">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className={`w-2 h-2 rounded-full shrink-0 ${
                      node.isLeader ? "bg-primary animate-pulse" :
                      isActive ? "bg-green-500 animate-pulse" : "bg-destructive"
                    }`} />
                    <span className="font-bold text-sm truncate" title={node.hostname}>{node.hostname}</span>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    {node.isLeader && (
                      <Badge variant="outline" className="bg-primary/15 text-primary border-primary/30 text-[9px] h-5 px-1.5">
                        <Shield className="w-2.5 h-2.5 mr-1" />LEADER
                      </Badge>
                    )}
                    <Badge
                      variant="outline"
                      className={`text-[9px] h-5 px-1.5 ${
                        isActive ? "border-green-500/40 text-green-500 bg-green-500/10" :
                        node.status === "INACTIVE" ? "border-yellow-500/40 text-yellow-500 bg-yellow-500/10" :
                        "border-destructive/40 text-destructive bg-destructive/10"
                      }`}
                    >
                      {node.status}
                    </Badge>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="pt-3 pb-4 px-4 space-y-3">
                <div className="grid grid-cols-2 gap-1.5 text-[10px] font-mono">
                  <div className="bg-muted/30 rounded p-2 border border-border/50">
                    <div className="text-muted-foreground mb-0.5">NODE_ID</div>
                    <div className="text-foreground truncate" title={node.nodeId}>{node.nodeId.substring(0, 10)}…</div>
                  </div>
                  <div className="bg-muted/30 rounded p-2 border border-border/50">
                    <div className="text-muted-foreground mb-0.5">IP_ADDR</div>
                    <div className="text-foreground">{node.ipAddress || "—"}</div>
                  </div>
                  <div className="bg-muted/30 rounded p-2 border border-border/50">
                    <div className="text-muted-foreground mb-0.5">ACTIVE_JOBS</div>
                    <div className="text-foreground font-bold flex items-center gap-1">
                      <Activity className="w-3 h-3 text-primary" />
                      {node.activeJobs || 0}
                    </div>
                  </div>
                  <div className="bg-muted/30 rounded p-2 border border-border/50">
                    <div className="text-muted-foreground mb-0.5">HEARTBEAT</div>
                    <HeartbeatAge ts={node.lastHeartbeatAt} />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                    <span>HEARTBEAT HEALTH</span>
                    <span className={heartbeatOk ? "text-green-500" : "text-destructive"}>
                      {heartbeatOk ? "HEALTHY" : "STALE"}
                    </span>
                  </div>
                  <div className="h-1 rounded bg-border overflow-hidden">
                    <div
                      className={`h-full rounded transition-all duration-500 ${
                        heartbeatOk ? "bg-green-500" : heartbeatDiff < 30 ? "bg-yellow-500" : "bg-destructive"
                      }`}
                      style={{ width: `${Math.max(0, Math.min(100, 100 - (heartbeatDiff / 30) * 100))}%` }}
                    />
                  </div>
                </div>

                {node.isLeader && (
                  <div className="text-[9px] text-center text-primary/70 border border-primary/15 bg-primary/5 rounded py-1.5 tracking-widest">
                    ◆ LEADER — EXECUTING ALL JOBS ◆
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
