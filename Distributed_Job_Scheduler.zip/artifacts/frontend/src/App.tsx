import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { Layout } from "@/components/layout";
import { useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { useEffect } from "react";

import Dashboard from "@/pages/dashboard";
import Login from "@/pages/login";
import Jobs from "@/pages/jobs";
import NewJob from "@/pages/job-new";
import JobDetail from "@/pages/job-detail";
import Executions from "@/pages/executions";
import Nodes from "@/pages/nodes";

const queryClient = new QueryClient();

function ProtectedRoute({ component: Component, ...rest }: any) {
  const { data: me, isLoading, error } = useGetMe({
    query: {
      queryKey: getGetMeQueryKey(),
      retry: false
    }
  });

  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && (error || !me)) {
      setLocation("/login");
    }
  }, [isLoading, error, me, setLocation]);

  if (isLoading) {
    return <div className="min-h-screen w-full flex items-center justify-center bg-background text-primary font-mono tracking-widest animate-pulse">AUTHORIZING...</div>;
  }

  if (error || !me) {
    return null;
  }

  return (
    <Layout>
      <Component {...rest} />
    </Layout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/" component={() => <ProtectedRoute component={Dashboard} />} />
      <Route path="/dashboard" component={() => <ProtectedRoute component={Dashboard} />} />
      <Route path="/jobs" component={() => <ProtectedRoute component={Jobs} />} />
      <Route path="/jobs/new" component={() => <ProtectedRoute component={NewJob} />} />
      <Route path="/jobs/:id" component={() => <ProtectedRoute component={JobDetail} />} />
      <Route path="/executions" component={() => <ProtectedRoute component={Executions} />} />
      <Route path="/nodes" component={() => <ProtectedRoute component={Nodes} />} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <div className="dark min-h-[100dvh] bg-background text-foreground selection:bg-primary/30">
            <Router />
          </div>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
